package com.farmbuild.place;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;

import java.util.Set;

/** Các luật về BlockState: so khớp, thứ tự xây, block nào cần sneak khi click vào. */
public final class StateRules {
    private StateRules() {}

    /**
     * Thuộc tính do thế giới/redstone tự tính hoặc không đặt được lúc đặt block → bỏ qua khi so khớp.
     * (delay/mode của repeater/comparator được chỉnh riêng bằng click phải, xem needsConfigure.)
     */
    private static final Set<String> IGNORED = Set.of(
        "waterlogged", "lit", "triggered", "power", "powered", "extended", "enabled", "locked", "shape",
        "distance", "persistent", "moisture", "north", "south", "east", "west", "up", "down", "attached",
        "disarmed", "conditional", "open", "age", "level", "rotation", "delay", "mode", "bites", "eggs",
        "hatch", "snowy", "in_wall", "occupied", "has_record", "has_book", "inverted", "hanging",
        "signal_fire", "stage", "berries", "honey_level", "candles", "pickles", "note", "instrument"
    );

    private static final String[] TIER2 = {
        "redstone_wire", "repeater", "comparator", "torch", "lever", "button", "pressure_plate", "rail",
        "carpet", "sign", "tripwire", "string", "lantern", "candle", "banner", "head", "skull"
    };
    private static final String[] TIER1 = {
        "hopper", "piston", "observer", "dispenser", "dropper", "chest", "barrel", "furnace", "smoker",
        "door", "trapdoor", "slab", "stairs", "glass_pane", "fence", "wall", "bed", "shulker", "cauldron",
        "composter", "target", "lectern", "daylight", "sculk", "scaffolding", "ladder", "vine"
    };
    private static final String[] INTERACTIVE = {
        "door", "trapdoor", "fence_gate", "button", "lever", "repeater", "comparator", "note_block",
        "crafting_table", "anvil", "_bed", "cake", "composter", "loom", "stonecutter", "grindstone",
        "smithing_table", "cartography_table", "lectern", "bell", "cauldron", "respawn_anchor", "daylight",
        "jukebox", "beacon", "enchanting_table"
    };

    public static String id(Block b) {
        return Registries.BLOCK.getId(b).getPath();
    }

    /** Cùng loại block và cùng các thuộc tính quan trọng (hướng, nửa trên/dưới, loại slab...). */
    public static boolean baseMatches(BlockState have, BlockState want) {
        if (have.getBlock() != want.getBlock()) return false;
        for (Property<?> p : want.getProperties()) {
            if (IGNORED.contains(p.getName())) continue;
            if (!have.contains(p)) return false;
            if (!have.get(p).equals(want.get(p))) return false;
        }
        return true;
    }

    /** Thuộc tính chỉ đổi được bằng click phải (không có trong lúc đặt): repeater, comparator, cửa, trapdoor, cổng, cần gạt... */
    static boolean isConfigurable(String path, String prop) {
        return switch (prop) {
            case "delay" -> true;
            case "mode" -> path.contains("comparator");
            case "open" -> !path.startsWith("iron_") && (path.endsWith("door") || path.endsWith("fence_gate"));
            case "powered" -> path.equals("lever");
            case "inverted" -> path.equals("daylight_detector");
            case "note" -> path.equals("note_block");
            default -> false;
        };
    }

    /** Đã đặt đúng loại nhưng sai trạng thái bấm (delay/mode/open/powered...) → cần click phải. */
    public static boolean needsConfigure(BlockState have, BlockState want) {
        if (have.getBlock() != want.getBlock()) return false;
        String path = id(want.getBlock());
        for (Property<?> p : want.getProperties()) {
            if (!isConfigurable(path, p.getName())) continue;
            if (have.contains(p) && !have.get(p).equals(want.get(p))) return true;
        }
        return false;
    }

    /** Nửa dưới của cửa/cây cao: nửa trên phải trống thì mới đặt được. */
    public static boolean hasLowerHalf(BlockState s) {
        for (Property<?> p : s.getProperties()) {
            if (p.getName().equals("half") && String.valueOf(s.get(p)).equals("lower")) return true;
        }
        return false;
    }

    /** 0 = khối nền/đặc, 1 = máy/khối có hướng, 2 = linh kiện gắn lên (dây, đuốc, repeater...). */
    public static int tier(BlockState s) {
        String path = id(s.getBlock());
        for (String k : TIER2) if (path.contains(k)) return 2;
        if (s.hasBlockEntity()) return 1;
        for (String k : TIER1) if (path.contains(k)) return 1;
        return 0;
    }

    /** Click vào block này bằng tay không sneak sẽ mở GUI/bật tắt → phải sneak khi đặt block lên nó. */
    public static boolean isInteractive(BlockState s) {
        if (s.hasBlockEntity()) return true;
        String path = id(s.getBlock());
        for (String k : INTERACTIVE) if (path.contains(k)) return true;
        return false;
    }

    /** Nửa trên của cửa/cây cao, đầu giường: tự xuất hiện khi đặt nửa dưới, không đặt riêng được. */
    public static boolean isDependentHalf(BlockState s) {
        for (Property<?> p : s.getProperties()) {
            String n = p.getName();
            String v = String.valueOf(s.get(p));
            if (n.equals("half") && v.equals("upper")) return true;
            if (n.equals("part") && v.equals("head")) return true;
        }
        return false;
    }
}
