package com.farmbuild.place;

import com.farmbuild.Config;
import com.farmbuild.mixin.BlockItemAccessor;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * "Bộ não đặt block": với một ô cần đặt, thử mọi cách đặt khả dĩ (đứng tựa vào block nào, click mặt nào,
 * điểm nào trên mặt, nhìn hướng nào) rồi GIẢ LẬP kết quả bằng chính hàm đặt block của game.
 * Chỉ chọn cách nào cho ra đúng trạng thái trong bản vẽ (đúng hướng, đúng nửa trên/dưới...).
 */
public final class PlacementSolver {
    private PlacementSolver() {}

    public record Plan(BlockPos support, Direction side, Vec3d hit, float yaw, float pitch,
                       boolean spoof, boolean sneak, boolean reachable) {
        /** Khoá nhận dạng một cách đặt (để nhớ cách nào đã cho ra sai trạng thái). */
        public String key() {
            return support.asLong() + ":" + side.name() + ":" + Math.round(hit.x * 100) + ":" + Math.round(hit.y * 100)
                + ":" + Math.round(hit.z * 100) + ":" + Math.round(yaw) + ":" + Math.round(pitch) + ":" + sneak;
        }
    }

    public static final class Result {
        /** null nếu hiện chưa có cách đặt nào cho ra đúng trạng thái (thường là chưa có block để tựa). */
        public Plan best;
        /** Người chơi đang đứng trong chính ô cần đặt. */
        public boolean entityBlocked;
    }

    private static final float[] HORIZONTAL_YAWS = {180f, 270f, 0f, 90f}; // bắc, đông, nam, tây

    public static Result solve(MinecraftClient mc, BlockPos target, BlockState desired, Config cfg) {
        return solve(mc, target, desired, cfg, null);
    }

    /** {@code bad}: các cách đặt (Plan.key) đã thử mà ra sai trạng thái → không dùng lại. */
    public static Result solve(MinecraftClient mc, BlockPos target, BlockState desired, Config cfg, Set<String> bad) {
        return solve(mc, target, desired, cfg, bad, null, cfg.visibleAim, cfg.reach);
    }

    /** Như solve nhưng cho phép góc nhìn \"ẩn\"/hướng khác (dùng khi không có cách đặt đúng bằng cách ngắm thẳng vào điểm click). */
    public static Result solveLegacy(MinecraftClient mc, BlockPos target, BlockState desired, Config cfg, Set<String> bad) {
        return solve(mc, target, desired, cfg, bad, null, false, cfg.reach);
    }

    /** Ngắm thẳng nếu được, không thì thử các hướng khác. */
    public static Result solveBest(MinecraftClient mc, BlockPos target, BlockState desired, Config cfg) {
        Result r = solve(mc, target, desired, cfg, null);
        if (r.best != null && r.best.reachable()) return r;
        Result r2 = solveLegacy(mc, target, desired, cfg, null);
        return (r2.best != null && (r.best == null || r2.best.reachable())) ? r2 : r;
    }

    /**
     * @param eyeOpt  vị trí mắt giả định (null = mắt hiện tại), dùng để tìm chỗ đứng
     * @param aimOnly chỉ xét góc quay ngắm thẳng vào điểm click
     */
    public static Result solve(MinecraftClient mc, BlockPos target, BlockState desired, Config cfg, Set<String> bad,
                               Vec3d eyeOpt, boolean aimOnly, double reach) {
        Result res = new Result();
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null) return res;

        Item item = desired.getBlock().asItem();
        if (!(item instanceof BlockItem bi)) return res;
        BlockItemAccessor acc = (BlockItemAccessor) (Object) bi;
        ItemStack stack = item.getDefaultStack();

        Vec3d eye = eyeOpt != null ? eyeOpt : p.getEyePos();
        double reachSq = reach * reach;
        double bestScore = Double.MAX_VALUE;

        for (Direction d : Direction.values()) {
            BlockPos sp = target.offset(d);
            if (!w.getChunkManager().isChunkLoaded(sp.getX() >> 4, sp.getZ() >> 4)) continue;
            BlockState ss = w.getBlockState(sp);
            // chỗ tựa phải là block thật sự (không phải air/cỏ/nước...), vì click vào block replaceable sẽ đặt đè lên nó
            if (ss.isAir() || ss.isReplaceable() || !ss.getFluidState().isEmpty()) continue;

            Direction side = d.getOpposite(); // mặt của block tựa hướng về ô cần đặt
            boolean sneak = cfg.alwaysSneak || StateRules.isInteractive(ss);

            for (Vec3d hv : hitPoints(sp, side)) {
                double d2 = eye.squaredDistanceTo(hv);
                boolean inReach = d2 <= reachSq;
                boolean ok = inReach && (!cfg.requireLineOfSight || visible(w, p, eye, hv, sp));
                BlockHitResult hit = new BlockHitResult(hv, side, sp, false);

                for (float[] rot : rotations(p, eye, hv, cfg.spoofRotation, aimOnly)) {
                    BlockState got = simulate(p, w, acc, stack, hit, rot[0], rot[1], sneak, target);
                    if (got == null || !StateRules.baseMatches(got, desired)) continue;

                    double score = (ok ? 0 : 1000) + (rot[2] != 0 ? 10 : 0) + (sneak ? 1 : 0) + Math.sqrt(d2) * 0.01;
                    if (score < bestScore) {
                        Plan cand = new Plan(sp, side, hv, rot[0], rot[1], rot[2] != 0, sneak, ok);
                        if (bad != null && bad.contains(cand.key())) continue;
                        bestScore = score;
                        res.best = cand;
                    }
                }
                // đã có cách tốt nhất có thể (trong tầm, nhìn thấy, không cần xoay ảo) → khỏi thử tiếp
                if (res.best != null && bestScore < 2.0) return res;
            }
        }

        if (res.best == null && new Box(target).intersects(p.getBoundingBox())) {
            res.entityBlocked = true;
        }
        return res;
    }

    /** Giả lập đặt block với góc nhìn/sneak cho trước; trả về trạng thái sẽ được đặt, hoặc null nếu không đặt được. */
    private static BlockState simulate(ClientPlayerEntity p, ClientWorld w, BlockItemAccessor acc, ItemStack stack,
                                       BlockHitResult hit, float yaw, float pitch, boolean sneak, BlockPos target) {
        float oy = p.getYaw();
        float op = p.getPitch();
        boolean oldForce = PlacementExecutor.forceSneak;
        try {
            p.setYaw(yaw);
            p.setPitch(pitch);
            PlacementExecutor.forceSneak = sneak;
            ItemPlacementContext ctx = new ItemPlacementContext(p, Hand.MAIN_HAND, stack, hit);
            if (!ctx.getBlockPos().equals(target) || !ctx.canPlace()) return null;
            return acc.farmbuild$getPlacementState(ctx);
        } catch (RuntimeException ex) {
            return null;
        } finally {
            p.setYaw(oy);
            p.setPitch(op);
            PlacementExecutor.forceSneak = oldForce;
        }
    }

    /** Các điểm click trên mặt {@code side} của block {@code sp}: tâm mặt, và (với mặt đứng) nửa trên/nửa dưới. */
    private static List<Vec3d> hitPoints(BlockPos sp, Direction side) {
        double cx = sp.getX() + 0.5 + side.getOffsetX() * 0.5;
        double cy = sp.getY() + 0.5 + side.getOffsetY() * 0.5;
        double cz = sp.getZ() + 0.5 + side.getOffsetZ() * 0.5;
        List<Vec3d> out = new ArrayList<>(3);
        out.add(new Vec3d(cx, cy, cz));
        if (side.getAxis() != Direction.Axis.Y) {
            out.add(new Vec3d(cx, cy + 0.25, cz)); // nửa trên (stairs/slab/trapdoor kiểu "top")
            out.add(new Vec3d(cx, cy - 0.25, cz)); // nửa dưới
        }
        return out;
    }

    /** Thứ tự thử: góc đang có (không cần xoay ảo) → nhìn thẳng vào điểm click → 4 hướng ngang → lên/xuống. */
    private static List<float[]> rotations(ClientPlayerEntity p, Vec3d eye, Vec3d hv, boolean spoof, boolean aimOnly) {
        List<float[]> out = new ArrayList<>(8);
        if (aimOnly) {
            float[] a = Aim.angles(eye, hv);
            out.add(new float[]{a[0], a[1], 0f});
            return out;
        }
        float cy = p.getYaw();
        float cp = p.getPitch();
        out.add(new float[]{cy, cp, 0f});
        if (!spoof) return out;

        double dx = hv.x - eye.x;
        double dy = hv.y - eye.y;
        double dz = hv.z - eye.z;
        double hd = Math.sqrt(dx * dx + dz * dz);
        float aimYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float aimPitch = (float) (-Math.toDegrees(Math.atan2(dy, hd)));
        addRot(out, aimYaw, aimPitch, cy, cp);
        for (float y : HORIZONTAL_YAWS) addRot(out, y, 0f, cy, cp);
        addRot(out, cy, -90f, cy, cp);
        addRot(out, cy, 90f, cy, cp);
        return out;
    }

    private static void addRot(List<float[]> out, float yaw, float pitch, float cy, float cp) {
        if (Math.abs(MathHelper.wrapDegrees(yaw - cy)) < 0.01f && Math.abs(pitch - cp) < 0.01f) return;
        out.add(new float[]{yaw, pitch, 1f});
    }

    /** Từ mắt nhìn thẳng tới điểm click thì chạm đúng block tựa (không bị vật khác che). */
    private static boolean visible(ClientWorld w, ClientPlayerEntity p, Vec3d eye, Vec3d hv, BlockPos sp) {
        Vec3d dir = hv.subtract(eye);
        double len = dir.length();
        if (len < 1.0e-6) return true;
        Vec3d end = hv.add(dir.multiply(0.05 / len)); // xuyên nhẹ vào trong block để raycast chắc chắn trúng
        BlockHitResult r = w.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.COLLIDER,
            RaycastContext.FluidHandling.NONE, p));
        return r.getType() == HitResult.Type.BLOCK && r.getBlockPos().equals(sp);
    }
}
