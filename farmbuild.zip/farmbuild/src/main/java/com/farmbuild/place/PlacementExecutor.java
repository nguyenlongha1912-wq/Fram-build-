package com.farmbuild.place;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;

/**
 * Thực hiện một lần click phải theo đúng trình tự của Easy Redstone:
 *   tick N  : queue()  → trước khi gửi packet di chuyển, đổi góc nhìn sang góc "ảo" (nếu cần)
 *   tick N  : (packet di chuyển mang góc ảo đi, góc thật được trả lại)
 *   cuối tick N: endTick() → gửi packet sneak (nếu cần) → interactBlock → trả sneak.
 * Nhờ vậy server đã nhận góc đúng TRƯỚC khi nhận lệnh đặt block.
 */
public final class PlacementExecutor {
    private PlacementExecutor() {}

    /** Bật trong lúc đặt: client coi như đang sneak (xem PlayerEntityMixin). */
    public static volatile boolean forceSneak;

    public record Job(BlockPos target, BlockHitResult hit, float yaw, float pitch, boolean spoof, boolean sneak, int hotbarSlot) {}

    private static Job pending;
    private static boolean spoofApplied;
    private static boolean spoofSent;
    private static int pendingTicks;
    private static float realYaw;
    private static float realPitch;

    /** Kết quả của lần click gần nhất (để FarmProcess biết). */
    public static volatile boolean lastAccepted;
    public static volatile long lastFinishedTick = -1;
    private static long clock;

    public static boolean busy() {
        return pending != null;
    }

    public static void queue(Job job) {
        pending = job;
        pendingTicks = 0;
        spoofSent = false;
        spoofApplied = false;
    }

    public static void clear() {
        pending = null;
        spoofApplied = false;
        spoofSent = false;
        forceSneak = false;
    }

    // ---- gọi từ ClientPlayerEntityMixin ----

    public static void beforeMovementPackets(ClientPlayerEntity p) {
        Job job = pending;
        if (job == null || spoofSent) return;
        if (!job.spoof()) {
            spoofSent = true;
            return;
        }
        realYaw = p.getYaw();
        realPitch = p.getPitch();
        p.setYaw(job.yaw());
        p.setPitch(job.pitch());
        spoofApplied = true;
    }

    public static void afterMovementPackets(ClientPlayerEntity p) {
        if (!spoofApplied) return;
        p.setYaw(realYaw);
        p.setPitch(realPitch);
        spoofApplied = false;
        spoofSent = true;
    }

    // ---- gọi cuối mỗi client tick ----

    public static void endTick(MinecraftClient mc) {
        clock++;
        Job job = pending;
        if (job == null) return;
        pendingTicks++;
        // chờ packet di chuyển (mang góc ảo) đi trước; quá 4 tick thì thôi, đặt luôn
        if (!spoofSent && pendingTicks < 4) return;

        pending = null;
        spoofSent = false;
        spoofApplied = false;

        ClientPlayerEntity p = mc.player;
        ClientPlayNetworkHandler net = mc.getNetworkHandler();
        if (p == null || net == null || mc.interactionManager == null) return;

        try {
            p.getInventory().setSelectedSlot(job.hotbarSlot());
            if (job.sneak()) {
                forceSneak = true;
                net.sendPacket(new PlayerInputC2SPacket(new PlayerInput(false, false, false, false, false, true, false)));
            }
            ActionResult r = mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, job.hit());
            lastAccepted = r.isAccepted();
            if (lastAccepted) p.swingHand(Hand.MAIN_HAND);
        } finally {
            if (job.sneak()) {
                forceSneak = false;
                net.sendPacket(new PlayerInputC2SPacket(new PlayerInput(false, false, false, false, false, false, false)));
            }
            lastFinishedTick = clock;
        }
    }
}
