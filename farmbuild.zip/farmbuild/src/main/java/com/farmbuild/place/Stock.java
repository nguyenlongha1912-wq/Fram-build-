package com.farmbuild.place;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

/** Kiểm tra vật liệu và đưa item lên hotbar. */
public final class Stock {
    private Stock() {}

    /** Creative luôn đủ; survival thì tìm trong 36 ô kho đồ. */
    public static boolean has(ClientPlayerEntity p, Item item) {
        if (p.isCreative()) return true;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 36; i++) {
            if (inv.getStack(i).isOf(item)) return true;
        }
        return false;
    }

    /** Đưa item lên hotbar, trả về chỉ số ô hotbar (0-8) hoặc -1 nếu không có. */
    public static int ensureHotbar(MinecraftClient mc, Item item) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return -1;
        PlayerInventory inv = p.getInventory();

        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isOf(item)) return i;
        }

        int slot = pickSwapSlot(inv);
        if (p.isCreative()) {
            ItemStack st = item.getDefaultStack();
            inv.setStack(slot, st);
            mc.interactionManager.clickCreativeStack(st, 36 + slot);
            return slot;
        }
        for (int i = 9; i < 36; i++) {
            if (inv.getStack(i).isOf(item)) {
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, i, slot, SlotActionType.SWAP, p);
                return slot;
            }
        }
        return -1;
    }

    /** Ưu tiên ô hotbar trống, không thì ô đang cầm. */
    private static int pickSwapSlot(PlayerInventory inv) {
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isEmpty()) return i;
        }
        return inv.getSelectedSlot();
    }
}
