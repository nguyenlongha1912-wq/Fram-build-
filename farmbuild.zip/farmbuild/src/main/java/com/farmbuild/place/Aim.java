package com.farmbuild.place;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Ngắm: tìm điểm trên block mà tia nhìn từ mắt chạm tới KHÔNG bị vật khác che (không xuyên tường), và tính góc quay. */
public final class Aim {
    private Aim() {}

    public record Point(Vec3d point, Direction side) {}

    private static final double[][] SAMPLES = {
        {0.5, 0.5, 0.5}, {0.5, 0.9, 0.5}, {0.5, 0.1, 0.5}, {0.1, 0.5, 0.5}, {0.9, 0.5, 0.5}, {0.5, 0.5, 0.1}, {0.5, 0.5, 0.9},
        {0.2, 0.8, 0.2}, {0.8, 0.8, 0.2}, {0.2, 0.8, 0.8}, {0.8, 0.8, 0.8}, {0.2, 0.2, 0.2}, {0.8, 0.2, 0.8}, {0.5, 0.05, 0.5}
    };

    /**
     * Điểm nhìn thấy được trên block {@code pos} từ mắt {@code eye} trong tầm {@code reach}, hoặc null nếu bị che/quá xa.
     * Điểm trả về là chỗ tia thực sự chạm vào block (đã tính cả hình dạng block).
     */
    public static Point visiblePoint(Vec3d eye, ClientWorld w, Entity e, BlockPos pos, double reach) {
        double reachSq = reach * reach;
        Point best = null;
        double bd = Double.MAX_VALUE;
        for (double[] s : SAMPLES) {
            Vec3d pt = new Vec3d(pos.getX() + s[0], pos.getY() + s[1], pos.getZ() + s[2]);
            double d2 = eye.squaredDistanceTo(pt);
            if (d2 > reachSq + 1.0) continue;
            double len = Math.sqrt(d2);
            if (len < 1.0e-6) continue;
            Vec3d end = eye.add(pt.subtract(eye).multiply((len + 1.0) / len)); // xuyên qua điểm mẫu để chắc chắn trúng
            BlockHitResult r = w.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.NONE, e));
            if (r.getType() != HitResult.Type.BLOCK || !r.getBlockPos().equals(pos)) continue;
            double hd = eye.squaredDistanceTo(r.getPos());
            if (hd > reachSq) continue;
            if (hd < bd) {
                bd = hd;
                best = new Point(r.getPos(), r.getSide());
            }
        }
        return best;
    }

    /** {yaw, pitch} để nhìn thẳng từ mắt tới điểm. */
    public static float[] angles(Vec3d eye, Vec3d pt) {
        double dx = pt.x - eye.x;
        double dy = pt.y - eye.y;
        double dz = pt.z - eye.z;
        double hd = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, hd)));
        return new float[]{yaw, pitch};
    }
}
