package com.farmbuild.schem;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/**
 * Bộ đọc NBT tối giản, không phụ thuộc Minecraft (nên không bị vỡ khi Mojang đổi API NBT).
 * Compound -> Map, List -> List, mảng -> byte[]/int[]/long[], số -> Byte/Short/Integer/Long/Float/Double.
 */
public final class Nbt {
    private Nbt() {}

    public static Map<String, Object> readFile(Path file) throws IOException {
        try (InputStream raw = new BufferedInputStream(Files.newInputStream(file))) {
            raw.mark(2);
            int a = raw.read();
            int b = raw.read();
            raw.reset();
            InputStream in = (a == 0x1f && b == 0x8b) ? new GZIPInputStream(raw) : raw;
            return read(new DataInputStream(new BufferedInputStream(in)));
        }
    }

    public static Map<String, Object> read(DataInputStream in) throws IOException {
        int type = in.readUnsignedByte();
        if (type != 10) {
            throw new IOException("Root NBT phải là compound, nhưng gặp type " + type);
        }
        in.readUTF();
        return compound(in, 0);
    }

    private static Map<String, Object> compound(DataInputStream in, int depth) throws IOException {
        if (depth > 512) throw new IOException("NBT lồng quá sâu");
        Map<String, Object> map = new LinkedHashMap<>();
        while (true) {
            int t = in.readUnsignedByte();
            if (t == 0) break;
            String name = in.readUTF();
            map.put(name, payload(in, t, depth + 1));
        }
        return map;
    }

    private static Object payload(DataInputStream in, int type, int depth) throws IOException {
        switch (type) {
            case 1: return in.readByte();
            case 2: return in.readShort();
            case 3: return in.readInt();
            case 4: return in.readLong();
            case 5: return in.readFloat();
            case 6: return in.readDouble();
            case 7: {
                int n = in.readInt();
                byte[] a = new byte[n];
                in.readFully(a);
                return a;
            }
            case 8: return in.readUTF();
            case 9: {
                if (depth > 512) throw new IOException("NBT lồng quá sâu");
                int et = in.readUnsignedByte();
                int n = in.readInt();
                List<Object> list = new ArrayList<>(Math.max(0, Math.min(n, 1 << 16)));
                for (int i = 0; i < n; i++) list.add(payload(in, et, depth + 1));
                return list;
            }
            case 10: return compound(in, depth + 1);
            case 11: {
                int n = in.readInt();
                int[] a = new int[n];
                for (int i = 0; i < n; i++) a[i] = in.readInt();
                return a;
            }
            case 12: {
                int n = in.readInt();
                long[] a = new long[n];
                for (int i = 0; i < n; i++) a[i] = in.readLong();
                return a;
            }
            default:
                throw new IOException("Tag NBT không hợp lệ: " + type);
        }
    }

    // ---- tiện ích ----

    public static int intOf(Object o, int def) {
        return o instanceof Number n ? n.intValue() : def;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> map(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : null;
    }

    @SuppressWarnings("unchecked")
    public static List<Object> list(Object o) {
        return o instanceof List ? (List<Object>) o : null;
    }
}
