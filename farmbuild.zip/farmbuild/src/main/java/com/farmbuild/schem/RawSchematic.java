package com.farmbuild.schem;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Giải mã .litematic và .nbt (structure) thành luồng (x, y, z, block) THUẦN JAVA,
 * không đụng tới Minecraft. Toạ độ trả về là toạ độ tương đối trong file; chuyển sang thế giới ở SchematicLoader.
 */
public final class RawSchematic {
    private RawSchematic() {}

    public record Entry(String name, Map<String, String> props) {
        public boolean isAir() {
            return name.equals("minecraft:air") || name.equals("minecraft:cave_air") || name.equals("minecraft:void_air")
                || name.equals("minecraft:structure_void");
        }
    }

    public interface Sink {
        void block(int x, int y, int z, Entry e);

        /** Báo hộp của một vùng (kể cả phần không khí). */
        default void region(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {}
    }

    // ---------------- .litematic ----------------

    public static void litematic(Map<String, Object> root, Sink sink) throws IOException {
        Map<String, Object> regions = Nbt.map(root.get("Regions"));
        if (regions == null || regions.isEmpty()) throw new IOException("File .litematic không có mục Regions");

        for (Map.Entry<String, Object> re : regions.entrySet()) {
            Map<String, Object> r = Nbt.map(re.getValue());
            if (r == null) continue;
            Map<String, Object> pos = Nbt.map(r.get("Position"));
            Map<String, Object> size = Nbt.map(r.get("Size"));
            if (pos == null || size == null) continue;

            int px = Nbt.intOf(pos.get("x"), 0), py = Nbt.intOf(pos.get("y"), 0), pz = Nbt.intOf(pos.get("z"), 0);
            int sx = Nbt.intOf(size.get("x"), 0), sy = Nbt.intOf(size.get("y"), 0), sz = Nbt.intOf(size.get("z"), 0);

            // Size âm nghĩa là vùng nằm "ngược" so với Position (Litematica cho phép lật)
            int minX = px + (sx < 0 ? sx + 1 : 0);
            int minY = py + (sy < 0 ? sy + 1 : 0);
            int minZ = pz + (sz < 0 ? sz + 1 : 0);
            int ax = Math.abs(sx), ay = Math.abs(sy), az = Math.abs(sz);
            if (ax == 0 || ay == 0 || az == 0) continue;
            sink.region(minX, minY, minZ, minX + ax - 1, minY + ay - 1, minZ + az - 1);

            Entry[] palette = palette(Nbt.list(r.get("BlockStatePalette")));
            if (palette.length == 0) continue;
            Object bs = r.get("BlockStates");
            if (!(bs instanceof long[] data)) throw new IOException("Region '" + re.getKey() + "' thiếu BlockStates");

            int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(palette.length - 1));

            for (int y = 0; y < ay; y++) {
                for (int z = 0; z < az; z++) {
                    for (int x = 0; x < ax; x++) {
                        long index = ((long) y * az + z) * ax + x;
                        int id = readPacked(data, index, bits);
                        if (id < 0 || id >= palette.length) continue;
                        Entry e = palette[id];
                        if (e.isAir()) continue;
                        sink.block(minX + x, minY + y, minZ + z, e);
                    }
                }
            }
        }
    }

    /** Litematica nén các chỉ số palette liên tiếp theo bit, KHÔNG chừa đệm ở cuối mỗi long. */
    static int readPacked(long[] data, long index, int bits) {
        long bitIndex = index * bits;
        int start = (int) (bitIndex >> 6);
        int end = (int) ((bitIndex + bits - 1) >> 6);
        int off = (int) (bitIndex & 63);
        long mask = (1L << bits) - 1L;
        if (end >= data.length) return -1;
        if (start == end) return (int) ((data[start] >>> off) & mask);
        return (int) (((data[start] >>> off) | (data[end] << (64 - off))) & mask);
    }

    // ---------------- .nbt (structure của vanilla) ----------------

    public static void structure(Map<String, Object> root, Sink sink) throws IOException {
        List<Object> pal = Nbt.list(root.get("palette"));
        if (pal == null) {
            List<Object> pals = Nbt.list(root.get("palettes"));
            if (pals != null && !pals.isEmpty()) pal = Nbt.list(pals.get(0));
        }
        List<Object> blocks = Nbt.list(root.get("blocks"));
        if (pal == null || blocks == null) throw new IOException("File .nbt không phải structure hợp lệ (thiếu palette/blocks)");

        List<Object> sz = Nbt.list(root.get("size"));
        if (sz != null && sz.size() >= 3) {
            sink.region(0, 0, 0, Nbt.intOf(sz.get(0), 1) - 1, Nbt.intOf(sz.get(1), 1) - 1, Nbt.intOf(sz.get(2), 1) - 1);
        }
        Entry[] palette = palette(pal);
        for (Object o : blocks) {
            Map<String, Object> b = Nbt.map(o);
            if (b == null) continue;
            List<Object> p = Nbt.list(b.get("pos"));
            if (p == null || p.size() < 3) continue;
            int id = Nbt.intOf(b.get("state"), -1);
            if (id < 0 || id >= palette.length) continue;
            Entry e = palette[id];
            if (e.isAir()) continue;
            sink.block(Nbt.intOf(p.get(0), 0), Nbt.intOf(p.get(1), 0), Nbt.intOf(p.get(2), 0), e);
        }
    }

    // ---------------- chung ----------------

    private static Entry[] palette(List<Object> raw) {
        if (raw == null) return new Entry[0];
        Entry[] out = new Entry[raw.size()];
        for (int i = 0; i < out.length; i++) {
            Map<String, Object> m = Nbt.map(raw.get(i));
            String name = "minecraft:air";
            Map<String, String> props = new LinkedHashMap<>();
            if (m != null) {
                if (m.get("Name") instanceof String s) name = s;
                Map<String, Object> pr = Nbt.map(m.get("Properties"));
                if (pr != null) {
                    for (Map.Entry<String, Object> pe : pr.entrySet()) props.put(pe.getKey(), String.valueOf(pe.getValue()));
                }
            }
            out[i] = new Entry(name, props);
        }
        return out;
    }
}
