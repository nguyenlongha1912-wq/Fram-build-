package com.farmbuild.schem;

import com.farmbuild.Config;
import com.farmbuild.place.StateRules;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Bản vẽ đã đặt vào thế giới: BlockPos → trạng thái mong muốn (không chứa air). */
public final class Blueprint {
    public final String name;
    /** Góc nhỏ nhất (x,y,z min) của công trình trong thế giới. */
    public final BlockPos origin;
    public final Map<BlockPos, BlockState> desired = new HashMap<>();

    /** Ô không đặt riêng được (nước, nửa trên cửa, piston head...) nhưng không phải \"block thừa\" nếu thế giới có thứ gì ở đó. */
    public final Set<BlockPos> keep = new HashSet<>();
    /** Các hộp (minX,minY,minZ,maxX,maxY,maxZ) của vùng bản vẽ, kể cả phần không khí. */
    public final List<int[]> boxes = new ArrayList<>();

    public int skippedFluid;
    public int skippedNoItem;
    public int skippedUnknown;
    public int skippedDependent;
    public int minY = Integer.MAX_VALUE;
    public int maxY = Integer.MIN_VALUE;

    public Blueprint(String name, BlockPos origin) {
        this.name = name;
        this.origin = origin;
    }

    public void add(BlockPos pos, BlockState st) {
        if (st == null) {
            keep.add(pos.toImmutable());
            skippedUnknown++;
            return;
        }
        if (st.isAir()) return;
        Block b = st.getBlock();
        if (b == Blocks.WATER || b == Blocks.LAVA || b == Blocks.BUBBLE_COLUMN
            || (Config.get().skipFluidBlocks && StateRules.isFluidish(st))) {
            keep.add(pos.toImmutable());
            skippedFluid++;
            return;
        }
        if (b.asItem() == Items.AIR) {
            keep.add(pos.toImmutable());
            skippedNoItem++;
            return;
        }
        if (StateRules.isDependentHalf(st)) {
            keep.add(pos.toImmutable());
            skippedDependent++;
            return;
        }
        desired.put(pos.toImmutable(), st);
        if (pos.getY() < minY) minY = pos.getY();
        if (pos.getY() > maxY) maxY = pos.getY();
    }

    public void addBox(int x0, int y0, int z0, int x1, int y1, int z1) {
        boxes.add(new int[]{Math.min(x0, x1), Math.min(y0, y1), Math.min(z0, z1), Math.max(x0, x1), Math.max(y0, y1), Math.max(z0, z1)});
    }

    /** Nếu loader không báo vùng nào thì dùng hộp bao quanh các block cần đặt. */
    public void ensureBox() {
        if (!boxes.isEmpty() || desired.isEmpty()) return;
        int x0 = Integer.MAX_VALUE, y0 = Integer.MAX_VALUE, z0 = Integer.MAX_VALUE;
        int x1 = Integer.MIN_VALUE, y1 = Integer.MIN_VALUE, z1 = Integer.MIN_VALUE;
        for (BlockPos p : desired.keySet()) {
            x0 = Math.min(x0, p.getX()); y0 = Math.min(y0, p.getY()); z0 = Math.min(z0, p.getZ());
            x1 = Math.max(x1, p.getX()); y1 = Math.max(y1, p.getY()); z1 = Math.max(z1, p.getZ());
        }
        addBox(x0, y0, z0, x1, y1, z1);
    }

    public int boxMinY() {
        int v = minY;
        for (int[] b : boxes) v = Math.min(v, b[1]);
        return v;
    }

    public int boxMaxY() {
        int v = maxY;
        for (int[] b : boxes) v = Math.max(v, b[4]);
        return v;
    }

    public int size() {
        return desired.size();
    }
}
