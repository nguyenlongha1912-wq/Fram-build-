package com.farmbuild.schem;

import com.farmbuild.place.StateRules;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.HashMap;
import java.util.Map;

/** Bản vẽ đã đặt vào thế giới: BlockPos → trạng thái mong muốn (không chứa air). */
public final class Blueprint {
    public final String name;
    /** Góc nhỏ nhất (x,y,z min) của công trình trong thế giới. */
    public final BlockPos origin;
    public final Map<BlockPos, BlockState> desired = new HashMap<>();

    public int skippedFluid;
    public int skippedNoItem;
    public int skippedUnknown;
    public int skippedDependent;
    public int minY = Integer.MAX_VALUE;
    public int maxY = Integer.MIN_VALUE;

    public Blueprint(String name, BlockPos origin) {
        this.name = name;
        this.origin = origin;
    }

    public void add(BlockPos pos, BlockState st) {
        if (st == null) {
            skippedUnknown++;
            return;
        }
        if (st.isAir()) return;
        Block b = st.getBlock();
        if (b == Blocks.WATER || b == Blocks.LAVA || b == Blocks.BUBBLE_COLUMN) {
            skippedFluid++;
            return;
        }
        if (b.asItem() == Items.AIR) {
            skippedNoItem++;
            return;
        }
        if (StateRules.isDependentHalf(st)) {
            skippedDependent++;
            return;
        }
        desired.put(pos.toImmutable(), st);
        if (pos.getY() < minY) minY = pos.getY();
        if (pos.getY() > maxY) maxY = pos.getY();
    }

    public int size() {
        return desired.size();
    }
}
