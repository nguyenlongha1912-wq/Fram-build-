package com.farmbuild.schem;

import baritone.api.BaritoneAPI;
import baritone.api.schematic.IStaticSchematic;
import baritone.api.schematic.format.ISchematicFormat;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

/** Đọc .litematic / .nbt bằng bộ đọc riêng; .schem/.schematic nhờ định dạng có sẵn của Baritone. */
public final class SchematicLoader {
    private SchematicLoader() {}

    public static Path dir() {
        return FabricLoader.getInstance().getGameDir().resolve("schematics");
    }

    public static List<String> listFiles() {
        List<String> out = new ArrayList<>();
        Path d = dir();
        if (!Files.isDirectory(d)) return out;
        try (Stream<Path> s = Files.list(d)) {
            s.filter(Files::isRegularFile).forEach(p -> {
                String n = p.getFileName().toString();
                String l = n.toLowerCase(Locale.ROOT);
                if (l.endsWith(".litematic") || l.endsWith(".nbt") || l.endsWith(".schem") || l.endsWith(".schematic")) out.add(n);
            });
        } catch (IOException ignored) {
        }
        out.sort(String.CASE_INSENSITIVE_ORDER);
        return out;
    }

    /** Tìm file theo tên (có hoặc không có đuôi) trong thư mục schematics. */
    public static Path resolve(String name) {
        Path d = dir();
        Path direct = d.resolve(name).normalize();
        if (direct.startsWith(d) && Files.isRegularFile(direct)) return direct;
        for (String ext : new String[]{".litematic", ".nbt", ".schem", ".schematic"}) {
            Path p = d.resolve(name + ext).normalize();
            if (p.startsWith(d) && Files.isRegularFile(p)) return p;
        }
        return null;
    }

    /** Góc nhỏ nhất của công trình sẽ nằm tại {@code origin}. */
    public static Blueprint load(Path file, BlockPos origin) throws Exception {
        String name = file.getFileName().toString();
        String lower = name.toLowerCase(Locale.ROOT);
        Blueprint bp = new Blueprint(name, origin.toImmutable());

        if (lower.endsWith(".litematic") || lower.endsWith(".nbt")) {
            List<int[]> coords = new ArrayList<>();
            List<RawSchematic.Entry> entries = new ArrayList<>();
            RawSchematic.Sink sink = (x, y, z, e) -> {
                coords.add(new int[]{x, y, z});
                entries.add(e);
            };
            Map<String, Object> root = Nbt.readFile(file);
            if (lower.endsWith(".litematic")) RawSchematic.litematic(root, sink);
            else RawSchematic.structure(root, sink);

            int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
            for (int[] c : coords) {
                minX = Math.min(minX, c[0]);
                minY = Math.min(minY, c[1]);
                minZ = Math.min(minZ, c[2]);
            }
            Map<RawSchematic.Entry, BlockState> cache = new IdentityHashMap<>();
            BlockPos.Mutable m = new BlockPos.Mutable();
            for (int i = 0; i < coords.size(); i++) {
                int[] c = coords.get(i);
                RawSchematic.Entry e = entries.get(i);
                BlockState st = cache.containsKey(e) ? cache.get(e) : toState(e);
                cache.put(e, st);
                m.set(origin.getX() + c[0] - minX, origin.getY() + c[1] - minY, origin.getZ() + c[2] - minZ);
                bp.add(m, st);
            }
        } else {
            Optional<ISchematicFormat> fmt = BaritoneAPI.getProvider().getSchematicSystem().getByFile(file.toFile());
            if (fmt.isEmpty()) throw new IOException("Định dạng không được hỗ trợ: " + name);
            IStaticSchematic s;
            try (InputStream in = Files.newInputStream(file)) {
                s = fmt.get().parse(in);
            }
            BlockPos.Mutable m = new BlockPos.Mutable();
            for (int y = 0; y < s.heightY(); y++) {
                for (int z = 0; z < s.lengthZ(); z++) {
                    for (int x = 0; x < s.widthX(); x++) {
                        m.set(origin.getX() + x, origin.getY() + y, origin.getZ() + z);
                        bp.add(m, s.getDirect(x, y, z));
                    }
                }
            }
        }
        return bp;
    }

    static BlockState toState(RawSchematic.Entry e) {
        Identifier id = Identifier.tryParse(e.name());
        if (id == null || !Registries.BLOCK.containsId(id)) return null;
        Block block = Registries.BLOCK.get(id);
        BlockState st = block.getDefaultState();
        for (Map.Entry<String, String> pe : e.props().entrySet()) {
            Property<?> p = block.getStateManager().getProperty(pe.getKey());
            if (p != null) st = withProp(st, p, pe.getValue());
        }
        return st;
    }

    private static <T extends Comparable<T>> BlockState withProp(BlockState st, Property<T> p, String v) {
        Optional<T> val = p.parse(v);
        return val.isPresent() ? st.with(p, val.get()) : st;
    }
}
