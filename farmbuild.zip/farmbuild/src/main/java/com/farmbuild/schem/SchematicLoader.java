package com.farmbuild.schem;

import baritone.api.BaritoneAPI;
import baritone.api.schematic.IStaticSchematic;
import baritone.api.schematic.format.ISchematicFormat;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

/** Đọc .litematic / .nbt bằng bộ đọc riêng; .schem/.schematic nhờ định dạng có sẵn của Baritone. */
public final class SchematicLoader {
    private SchematicLoader() {}

    public static Path dir() {
        return FabricLoader.getInstance().getGameDir().resolve("schematics");
    }

    public static List<String> listFiles() {
        List<String> out = new ArrayList<>();
        Path d = dir();
        if (!Files.isDirectory(d)) return out;
        try (Stream<Path> s = Files.list(d)) {
            s.filter(Files::isRegularFile).forEach(p -> {
                String n = p.getFileName().toString();
                String l = n.toLowerCase(Locale.ROOT);
                if (l.endsWith(".litematic") || l.endsWith(".nbt") || l.endsWith(".schem") || l.endsWith(".schematic")) out.add(n);
            });
        } catch (IOException ignored) {
        }
        out.sort(String.CASE_INSENSITIVE_ORDER);
        return out;
    }

    /** Tìm file theo tên (có hoặc không có đuôi) trong thư mục schematics. */
    public static Path resolve(String name) {
        Path d = dir();
        Path direct = d.resolve(name).normalize();
        if (direct.startsWith(d) && Files.isRegularFile(direct)) return direct;
        for (String ext : new String[]{".litematic", ".nbt", ".schem", ".schematic"}) {
            Path p = d.resolve(name + ext).normalize();
            if (p.startsWith(d) && Files.isRegularFile(p)) return p;
        }
        return null;
    }

    private static final class Collector implements RawSchematic.Sink {
        final List<int[]> coords = new ArrayList<>();
        final List<RawSchematic.Entry> entries = new ArrayList<>();
        final List<int[]> boxes = new ArrayList<>();

        @Override
        public void block(int x, int y, int z, RawSchematic.Entry e) {
            coords.add(new int[]{x, y, z});
            entries.add(e);
        }

        @Override
        public void region(int a, int b, int c, int d, int e, int f) {
            boxes.add(new int[]{a, b, c, d, e, f});
        }
    }

    private static Collector read(Path file, String lower) throws Exception {
        Collector col = new Collector();
        Map<String, Object> root = Nbt.readFile(file);
        if (lower.endsWith(".litematic")) RawSchematic.litematic(root, col);
        else RawSchematic.structure(root, col);
        return col;
    }

    /** Góc nhỏ nhất của công trình sẽ nằm tại {@code origin}. */
    public static Blueprint load(Path file, BlockPos origin) throws Exception {
        String name = file.getFileName().toString();
        String lower = name.toLowerCase(Locale.ROOT);
        Blueprint bp = new Blueprint(name, origin.toImmutable());

        if (lower.endsWith(".litematic") || lower.endsWith(".nbt")) {
            Collector col = read(file, lower);
            int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
            for (int[] c : col.coords) {
                minX = Math.min(minX, c[0]);
                minY = Math.min(minY, c[1]);
                minZ = Math.min(minZ, c[2]);
            }
            if (col.coords.isEmpty()) { minX = 0; minY = 0; minZ = 0; }
            Map<RawSchematic.Entry, BlockState> cache = new IdentityHashMap<>();
            BlockPos.Mutable m = new BlockPos.Mutable();
            for (int i = 0; i < col.coords.size(); i++) {
                int[] c = col.coords.get(i);
                RawSchematic.Entry e = col.entries.get(i);
                BlockState st = cache.containsKey(e) ? cache.get(e) : toState(e);
                cache.put(e, st);
                m.set(origin.getX() + c[0] - minX, origin.getY() + c[1] - minY, origin.getZ() + c[2] - minZ);
                bp.add(m, st);
            }
            for (int[] b : col.boxes) {
                bp.addBox(origin.getX() + b[0] - minX, origin.getY() + b[1] - minY, origin.getZ() + b[2] - minZ,
                    origin.getX() + b[3] - minX, origin.getY() + b[4] - minY, origin.getZ() + b[5] - minZ);
            }
        } else {
            Optional<ISchematicFormat> fmt = BaritoneAPI.getProvider().getSchematicSystem().getByFile(file.toFile());
            if (fmt.isEmpty()) throw new IOException("Định dạng không được hỗ trợ: " + name);
            IStaticSchematic s;
            try (InputStream in = Files.newInputStream(file)) {
                s = fmt.get().parse(in);
            }
            BlockPos.Mutable m = new BlockPos.Mutable();
            for (int y = 0; y < s.heightY(); y++) {
                for (int z = 0; z < s.lengthZ(); z++) {
                    for (int x = 0; x < s.widthX(); x++) {
                        m.set(origin.getX() + x, origin.getY() + y, origin.getZ() + z);
                        bp.add(m, s.getDirect(x, y, z));
                    }
                }
            }
            bp.addBox(origin.getX(), origin.getY(), origin.getZ(),
                origin.getX() + s.widthX() - 1, origin.getY() + s.heightY() - 1, origin.getZ() + s.lengthZ() - 1);
        }
        bp.ensureBox();
        return bp;
    }

    /** Mirror rồi rotation quanh origin (giống Litematica). Trả {x, z} mới. */
    private static int[] tf(int x, int z, BlockRotation rot, BlockMirror mir) {
        if (mir == BlockMirror.LEFT_RIGHT) z = -z;
        else if (mir == BlockMirror.FRONT_BACK) x = -x;
        if (rot == BlockRotation.CLOCKWISE_90) return new int[]{-z, x};
        if (rot == BlockRotation.CLOCKWISE_180) return new int[]{-x, -z};
        if (rot == BlockRotation.COUNTERCLOCKWISE_90) return new int[]{z, -x};
        return new int[]{x, z};
    }

    /**
     * Nạp đúng như Litematica đang đặt: toạ độ trong file được cộng thẳng vào {@code origin}
     * (KHÔNG dời về góc nhỏ nhất), có áp dụng mirror rồi rotation quanh origin.
     * Chỉ .litematic/.nbt; định dạng khác rơi về {@link #load}.
     */
    public static Blueprint loadPlaced(Path file, BlockPos origin, BlockRotation rot, BlockMirror mir) throws Exception {
        String name = file.getFileName().toString();
        String lower = name.toLowerCase(Locale.ROOT);
        if (!(lower.endsWith(".litematic") || lower.endsWith(".nbt"))) return load(file, origin);

        Blueprint bp = new Blueprint(name, origin.toImmutable());
        Collector col = read(file, lower);

        Map<RawSchematic.Entry, BlockState> cache = new IdentityHashMap<>();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int i = 0; i < col.coords.size(); i++) {
            int[] c = col.coords.get(i);
            int[] t = tf(c[0], c[2], rot, mir);
            RawSchematic.Entry e = col.entries.get(i);
            BlockState st = cache.containsKey(e) ? cache.get(e) : toState(e);
            cache.put(e, st);
            if (st != null) st = st.mirror(mir).rotate(rot);
            m.set(origin.getX() + t[0], origin.getY() + c[1], origin.getZ() + t[1]);
            bp.add(m, st);
        }
        for (int[] b : col.boxes) {
            int[] a = tf(b[0], b[2], rot, mir);
            int[] d = tf(b[3], b[5], rot, mir);
            bp.addBox(origin.getX() + a[0], origin.getY() + b[1], origin.getZ() + a[1],
                origin.getX() + d[0], origin.getY() + b[4], origin.getZ() + d[1]);
        }
        bp.ensureBox();
        return bp;
    }

    static BlockState toState(RawSchematic.Entry e) {
        Identifier id = Identifier.tryParse(e.name());
        if (id == null || !Registries.BLOCK.containsId(id)) return null;
        Block block = Registries.BLOCK.get(id);
        BlockState st = block.getDefaultState();
        for (Map.Entry<String, String> pe : e.props().entrySet()) {
            Property<?> p = block.getStateManager().getProperty(pe.getKey());
            if (p != null) st = withProp(st, p, pe.getValue());
        }
        return st;
    }

    private static <T extends Comparable<T>> BlockState withProp(BlockState st, Property<T> p, String v) {
        Optional<T> val = p.parse(v);
        return val.isPresent() ? st.with(p, val.get()) : st;
    }
}
