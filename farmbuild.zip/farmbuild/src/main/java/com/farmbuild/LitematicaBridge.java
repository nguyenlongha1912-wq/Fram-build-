package com.farmbuild;

import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;

import java.io.File;
import java.lang.reflect.Method;
import java.nio.file.Path;
import java.util.Collection;

/** Đọc placement Litematica đang chọn bằng reflection (không cần Litematica lúc biên dịch). */
final class LitematicaBridge {
    private LitematicaBridge() {}

    record Placement(Path file, BlockPos origin, BlockRotation rotation, BlockMirror mirror) {}

    private static Object call(Object o, String name) throws Exception {
        Method m = o.getClass().getMethod(name);
        return m.invoke(o);
    }

    private static Path toPath(Object o) {
        if (o == null) return null;
        if (o instanceof java.util.Optional<?> op) return op.isPresent() ? toPath(op.get()) : null;
        if (o instanceof Path pp) return pp;
        if (o instanceof File ff) return ff.toPath();
        if (o instanceof String ss && !ss.isEmpty()) return Path.of(ss);
        return null;
    }

    /** Ném Exception với thông báo tiếng Việt nếu không lấy được. */
    static Placement current() throws Exception {
        Object mgr;
        try {
            Class<?> dm = Class.forName("fi.dy.masa.litematica.data.DataManager");
            mgr = dm.getMethod("getSchematicPlacementManager").invoke(null);
        } catch (ClassNotFoundException e) {
            throw new Exception("Chưa cài Litematica (hoặc không tìm thấy lớp của nó).");
        }

        Object p = call(mgr, "getSelectedSchematicPlacement");
        if (p == null) {
            Object all = call(mgr, "getAllSchematicsPlacements");
            if (all instanceof Collection<?> c) {
                if (c.size() == 1) p = c.iterator().next();
                else if (c.isEmpty()) throw new Exception("Litematica chưa có bản vẽ nào được đặt (Load schematic rồi đặt bằng Placement).");
                else throw new Exception("Có " + c.size() + " placement. Hãy chọn một cái trong Litematica (menu Placements → Select).");
            }
        }
        if (p == null) throw new Exception("Không lấy được placement từ Litematica.");

        StringBuilder diag = new StringBuilder();
        Path f = null;
        Object sch = null;
        try {
            sch = call(p, "getSchematic");
        } catch (Exception e) {
            diag.append(" [getSchematic: ").append(e).append("]");
        }
        // Litematica bản mới trả Optional<Path>, bản cũ trả File — thử mọi cách.
        Object[][] tries = {{p, "getSchematicFile"}, {sch, "getFile"}, {sch, "getSchematicFile"}, {p, "getFile"}};
        for (Object[] t : tries) {
            if (f != null || t[0] == null) continue;
            try {
                Object r = call(t[0], (String) t[1]);
                f = toPath(r);
                diag.append(" [").append(t[1]).append("=").append(r == null ? "null" : r.getClass().getSimpleName()).append("]");
            } catch (NoSuchMethodException ignored) {
            } catch (Exception e) {
                diag.append(" [").append(t[1]).append(": ").append(e).append("]");
            }
        }
        if (f == null) throw new Exception("Không tìm ra file của bản vẽ trong Litematica." + diag);

        Object origin = call(p, "getOrigin");
        Object rot = call(p, "getRotation");
        Object mir = call(p, "getMirror");
        if (!(origin instanceof BlockPos bp)) throw new Exception("Không đọc được vị trí placement.");
        return new Placement(f, bp,
            rot instanceof BlockRotation r ? r : BlockRotation.NONE,
            mir instanceof BlockMirror mm ? mm : BlockMirror.NONE);
    }
}
