package com.farmbuild;

import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;

import java.io.File;
import java.lang.reflect.Method;
import java.nio.file.Path;
import java.util.Collection;

/** Đọc placement Litematica đang chọn bằng reflection (không cần Litematica lúc biên dịch). */
final class LitematicaBridge {
    private LitematicaBridge() {}

    record Placement(Path file, BlockPos origin, BlockRotation rotation, BlockMirror mirror) {}

    private static Object call(Object o, String name) throws Exception {
        Method m = o.getClass().getMethod(name);
        return m.invoke(o);
    }

    /** Ném Exception với thông báo tiếng Việt nếu không lấy được. */
    static Placement current() throws Exception {
        Object mgr;
        try {
            Class<?> dm = Class.forName("fi.dy.masa.litematica.data.DataManager");
            mgr = dm.getMethod("getSchematicPlacementManager").invoke(null);
        } catch (ClassNotFoundException e) {
            throw new Exception("Chưa cài Litematica (hoặc không tìm thấy lớp của nó).");
        }

        Object p = call(mgr, "getSelectedSchematicPlacement");
        if (p == null) {
            Object all = call(mgr, "getAllSchematicsPlacements");
            if (all instanceof Collection<?> c) {
                if (c.size() == 1) p = c.iterator().next();
                else if (c.isEmpty()) throw new Exception("Litematica chưa có bản vẽ nào được đặt (Load schematic rồi đặt bằng Placement).");
                else throw new Exception("Có " + c.size() + " placement. Hãy chọn một cái trong Litematica (menu Placements → Select).");
            }
        }
        if (p == null) throw new Exception("Không lấy được placement từ Litematica.");

        File f = null;
        try {
            Object o = call(p, "getSchematicFile");
            if (o instanceof File ff) f = ff;
        } catch (NoSuchMethodException ignored) {
        }
        if (f == null) {
            try {
                Object sch = call(p, "getSchematic");
                Object o = call(sch, "getFile");
                if (o instanceof File ff) f = ff;
            } catch (Exception ignored) {
            }
        }
        if (f == null) throw new Exception("Bản vẽ này chỉ có trong bộ nhớ (chưa lưu thành file) nên không đọc được.");

        Object origin = call(p, "getOrigin");
        Object rot = call(p, "getRotation");
        Object mir = call(p, "getMirror");
        if (!(origin instanceof BlockPos bp)) throw new Exception("Không đọc được vị trí placement.");
        return new Placement(f.toPath(), bp,
            rot instanceof BlockRotation r ? r : BlockRotation.NONE,
            mir instanceof BlockMirror mm ? mm : BlockMirror.NONE);
    }
}
