package com.farmbuild;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import com.farmbuild.place.PlacementExecutor;
import com.farmbuild.process.FarmProcess;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class FarmBuildClient implements ClientModInitializer {
    private static FarmProcess process;
    private static IBaritone registeredOn;

    /** null nếu Baritone chưa sẵn sàng (chưa vào game). */
    public static FarmProcess process() {
        ensureRegistered();
        return process;
    }

    /** Gọi từ InteractMixin cho mọi lần click đặt block không phải của FarmBuild. */
    public static void onInteract(net.minecraft.client.network.ClientPlayerEntity p, net.minecraft.util.Hand hand,
                                  net.minecraft.util.hit.BlockHitResult hit) {
        FarmProcess pr = process;
        if (pr != null) pr.noteInteract(p, hand, hit);
    }

    @Override
    public void onInitializeClient() {
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("farmbuild", "main"));
        KeyBinding toggle = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.farmbuild.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ensureRegistered();
            PlacementExecutor.endTick(client);
            while (toggle.wasPressed()) {
                toggle(client);
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> FarmCommands.register(dispatcher));
    }

    /** Đăng ký process vào Baritone (một lần cho mỗi instance Baritone). */
    private static void ensureRegistered() {
        try {
            IBaritone b = BaritoneAPI.getProvider().getPrimaryBaritone();
            if (b != null && b != registeredOn) {
                FarmProcess old = process;
                if (old != null && old.isRunning()) old.stop("Baritone được tạo lại.");
                process = new FarmProcess(b);
                b.getPathingControlManager().registerProcess(process);
                registeredOn = b;
            }
        } catch (Throwable ignored) {
            // Baritone chưa khởi tạo xong, thử lại ở tick sau
        }
    }

    private static void toggle(MinecraftClient client) {
        if (client.player == null) return;
        FarmProcess p = process();
        if (p == null) {
            client.player.sendMessage(Text.literal("§b[FarmBuild]§r Baritone chưa sẵn sàng."), false);
            return;
        }
        if (p.isRunning()) {
            p.stop("Đã dừng.");
        } else {
            String err = p.start();
            if (err != null) client.player.sendMessage(Text.literal("§b[FarmBuild]§r §c" + err), false);
        }
    }
}
