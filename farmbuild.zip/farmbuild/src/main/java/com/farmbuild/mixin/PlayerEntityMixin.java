package com.farmbuild.mixin;

import com.farmbuild.place.PlacementExecutor;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Giống Easy Redstone: trong lúc mod đang đặt block, ép client coi như đang sneak
 * để click vào rương/phễu/cửa... không mở GUI mà đặt block lên đó.
 */
@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {
    @Inject(method = "shouldCancelInteraction", at = @At("HEAD"), cancellable = true)
    private void farmbuild$forceSneak(CallbackInfoReturnable<Boolean> cir) {
        if (PlacementExecutor.forceSneak && (Object) this instanceof ClientPlayerEntity) {
            cir.setReturnValue(true);
        }
    }
}
