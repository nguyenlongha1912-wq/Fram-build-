package com.farmbuild.mixin;

import com.farmbuild.FarmBuildClient;
import com.farmbuild.place.PlacementExecutor;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Bắt các lần đặt block của Baritone (leo/bắc cầu) để biết kính nào là kính giàn giáo mà phá đi sau. */
@Mixin(ClientPlayerInteractionManager.class)
public abstract class InteractMixin {
    @Inject(method = "interactBlock", at = @At("HEAD"))
    private void farmbuild$track(ClientPlayerEntity player, Hand hand, BlockHitResult hit, CallbackInfoReturnable<ActionResult> cir) {
        if (PlacementExecutor.ownClick) return;
        FarmBuildClient.onInteract(player, hand, hit);
    }
}
