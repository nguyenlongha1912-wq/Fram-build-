package com.farmbuild.mixin;

import com.farmbuild.place.PlacementExecutor;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Cùng điểm chèn với Easy Redstone: đổi yaw/pitch ngay trước khi gửi packet di chuyển
 * (server nhận góc "ảo"), rồi trả lại góc thật ngay sau đó → camera của bạn không bị giật.
 */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void farmbuild$before(CallbackInfo ci) {
        PlacementExecutor.beforeMovementPackets((ClientPlayerEntity) (Object) this);
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"))
    private void farmbuild$after(CallbackInfo ci) {
        PlacementExecutor.afterMovementPackets((ClientPlayerEntity) (Object) this);
    }
}
