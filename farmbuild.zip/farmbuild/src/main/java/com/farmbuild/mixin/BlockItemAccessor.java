package com.farmbuild.mixin;

import net.minecraft.block.BlockState;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Cho phép gọi BlockItem.getPlacementState (protected) để GIẢ LẬP kết quả đặt block mà không đặt thật.
 * Dùng hàm của Item (không phải của Block) để đúng với đuốc/đuốc tường, biển, banner...
 */
@Mixin(BlockItem.class)
public interface BlockItemAccessor {
    @Invoker("getPlacementState")
    BlockState farmbuild$getPlacementState(ItemPlacementContext context);
}
