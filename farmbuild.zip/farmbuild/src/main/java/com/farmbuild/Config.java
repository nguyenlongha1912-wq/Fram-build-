package com.farmbuild;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;

/** Cấu hình lưu ở config/farmbuild.json. Đổi trong game bằng: /farmbuild set <khoá> <giá trị>. */
public final class Config {
    /** Tầm với (block) khi chọn điểm click. Vanilla cho 4.5; để 4.0 cho an toàn. */
    public double reach = 4.0;
    /** Số tick nghỉ giữa hai lần đặt (2 = ~10 block/giây, 1 = ~20 block/giây). */
    public int placeDelay = 2;
    /** Bán kính (block) quanh người chơi được ưu tiên đặt "tiện đường" trước khi đi xa. */
    public int nearRadius = 10;
    /** Ngân sách thời gian lập kế hoạch mỗi tick (ms). */
    public double planBudgetMs = 3.0;
    /** Chu kỳ quét lại thế giới (tick). */
    public int scanInterval = 20;
    /** Bắt buộc có đường nhìn thẳng tới mặt block sẽ click (an toàn hơn với anti-cheat). */
    public boolean requireLineOfSight = true;
    /** Đổi góc nhìn "ảo" quanh packet di chuyển như Easy Redstone (camera không giật). */
    public boolean spoofRotation = true;
    /** Luôn sneak khi click (mặc định chỉ sneak khi click vào rương/phễu/cửa/nút...). */
    public boolean alwaysSneak = false;
    /** Phá block sai/vướng trong vùng xây. Mặc định tắt cho an toàn. */
    public boolean breakWrong = false;
    /** Cho Baritone đặt block để bắc cầu/leo cột (allowPlace). */
    public boolean allowScaffold = true;
    /** Cho Baritone phá block khi đi (allowBreak). */
    public boolean allowBaritoneBreak = false;
    /** Bán kính tới đích khi đi bộ (GoalNear). Tự giảm khi thất bại. */
    public int goalRange = 3;
    /** Số lần thử tối đa cho một ô trước khi coi là bị kẹt. */
    public int maxAttempts = 5;
    /** Nếu quá số giây này không tiến triển, dừng và báo cáo. */
    public int stallSeconds = 45;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Config instance;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("farmbuild.json");
    }

    public static Config get() {
        if (instance == null) {
            try {
                Path f = file();
                if (Files.exists(f)) instance = GSON.fromJson(Files.readString(f), Config.class);
            } catch (Exception ignored) {
            }
            if (instance == null) {
                instance = new Config();
                save();
            }
        }
        return instance;
    }

    public static void save() {
        try {
            Files.writeString(file(), GSON.toJson(get()));
        } catch (Exception ignored) {
        }
    }

    /** Trả về null nếu OK, hoặc thông báo lỗi. */
    public static String set(String key, String value) {
        try {
            Field f = Config.class.getField(key);
            Class<?> t = f.getType();
            Config c = get();
            if (t == boolean.class) f.setBoolean(c, Boolean.parseBoolean(value));
            else if (t == int.class) f.setInt(c, Integer.parseInt(value));
            else if (t == double.class) f.setDouble(c, Double.parseDouble(value));
            else return "Kiểu không hỗ trợ: " + t;
            save();
            return null;
        } catch (NoSuchFieldException e) {
            return "Không có khoá '" + key + "'. Xem config/farmbuild.json để biết các khoá.";
        } catch (NumberFormatException e) {
            return "Giá trị không hợp lệ: " + value;
        } catch (Exception e) {
            return e.toString();
        }
    }
}
