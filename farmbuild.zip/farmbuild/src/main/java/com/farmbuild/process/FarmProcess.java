package com.farmbuild.process;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import baritone.api.Settings;
import baritone.api.pathing.goals.Goal;
import baritone.api.pathing.goals.GoalInverted;
import baritone.api.pathing.goals.GoalNear;
import baritone.api.process.IBaritoneProcess;
import baritone.api.process.PathingCommand;
import baritone.api.process.PathingCommandType;
import com.farmbuild.Config;
import com.farmbuild.place.PlacementExecutor;
import com.farmbuild.place.PlacementSolver;
import com.farmbuild.place.StateRules;
import com.farmbuild.place.Stock;
import com.farmbuild.schem.Blueprint;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

/**
 * Tiến trình xây dựng, cắm thẳng vào hệ thống process của Baritone (giống BuilderProcess của chính nó):
 *  - mỗi tick: so bản vẽ với thế giới → danh sách ô còn sai;
 *  - có ô đặt được ngay trong tầm tay → đặt (kiểu Easy Redstone) và yêu cầu Baritone tạm dừng;
 *  - không có → giao cho Baritone một GoalNear tới ô tốt nhất kế tiếp (Baritone lo bắc cầu/leo/nhảy/tránh nguy hiểm).
 */
public final class FarmProcess implements IBaritoneProcess {
    private final IBaritone baritone;
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private Blueprint bp;
    private boolean running;

    private final Set<BlockPos> remaining = new HashSet<>();
    private final Map<BlockPos, Integer> attempts = new HashMap<>();
    private final Map<BlockPos, Long> retryAt = new HashMap<>();
    private final Map<BlockPos, Long> verifyUntil = new HashMap<>();
    private final Map<BlockPos, String> whyNot = new HashMap<>();
    private final Map<BlockPos, String> blocked = new LinkedHashMap<>();
    private final Map<Item, Integer> missing = new LinkedHashMap<>();
    private final Map<BlockState, Integer> tierCache = new IdentityHashMap<>();

    private long tick;
    private long lastScan;
    private long lastFull;
    private long nextActionTick;
    private long lastProgressTick;
    private long breakStartedTick;
    private int lastRemainingSize;
    private int placed;
    private int alreadyCorrect;
    private BlockPos currentTarget;
    private Goal lastGoal;
    private int arrivedTicks;
    private BlockPos breaking;

    /** Tầng (Y) đang xây; chỉ làm tầng này, xong mới lên tầng kế. */
    private int layerY;
    private int topY;
    private int lastAnnouncedLayer;
    /** Tầng hiện tại đã hết việc làm được nhưng còn ô kẹt → không được lên tầng trên. */
    private boolean layerStuck;
    /** Block thừa (không có trong bản vẽ) nằm trong vùng bản vẽ ở tầng hiện tại. */
    private final Set<BlockPos> extras = new HashSet<>();
    private final Map<BlockPos, Integer> noSolve = new HashMap<>();
    /** Kính tạm đang đặt làm điểm tựa: vị trí → tick lúc đặt. */
    private final Map<BlockPos, Long> tempGlass = new HashMap<>();
    private final Map<BlockPos, Integer> tempUsed = new HashMap<>();
    private static final BlockState GLASS = Blocks.GLASS.getDefaultState();

    private Boolean savedAllowBreak;
    private Boolean savedAllowPlace;

    public FarmProcess(IBaritone baritone) {
        this.baritone = baritone;
    }

    // ================= API cho lệnh / phím =================

    public void setBlueprint(Blueprint blueprint) {
        if (running) stop("Nạp bản vẽ mới nên dừng bản cũ.");
        this.bp = blueprint;
        resetState();
    }

    public Blueprint blueprint() {
        return bp;
    }

    public boolean isRunning() {
        return running;
    }

    /** @return null nếu OK, hoặc thông báo lỗi. */
    public String start() {
        if (bp == null) return "Chưa nạp bản vẽ. Dùng: /farmbuild load <tên file>";
        if (mc.player == null || mc.world == null) return "Chưa vào thế giới.";
        resetState();
        applyBaritoneSettings();
        try {
            baritone.getPathingBehavior().cancelEverything();
        } catch (Throwable ignored) {
        }
        running = true;
        say("Bắt đầu xây §e" + bp.name + "§r (" + bp.size() + " block). Dừng bằng phím K hoặc /farmbuild stop.");
        return null;
    }

    public void stop(String reason) {
        boolean was = running;
        running = false;
        PlacementExecutor.clear();
        restoreBaritoneSettings();
        try {
            baritone.getPathingBehavior().cancelEverything();
        } catch (Throwable ignored) {
        }
        currentTarget = null;
        lastGoal = null;
        breaking = null;
        if (was) {
            say(reason);
            report();
        }
    }

    public String status() {
        if (bp == null) return "Chưa nạp bản vẽ.";
        return (running ? "§aĐang xây§r " : "§7Đang dừng§r ") + bp.name + ": tầng Y=" + layerY + ", đã đặt " + placed + ", còn " + remaining.size()
            + " ô, thừa cần phá " + extras.size() + ", kẹt " + blocked.size() + ".";
    }

    // ================= IBaritoneProcess =================

    @Override
    public boolean isActive() {
        return running;
    }

    @Override
    public boolean isTemporary() {
        return false;
    }

    @Override
    public void onLostControl() {
        lastGoal = null;
        PlacementExecutor.clear();
    }

    @Override
    public String displayName0() {
        return "FarmBuild " + (bp == null ? "" : bp.name);
    }

    @Override
    public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null || bp == null) {
            stop("Mất kết nối với thế giới.");
            return pause();
        }
        Config cfg = Config.get();
        tick++;

        if (calcFailed && currentTarget != null) {
            fail(currentTarget, "không có đường đi bộ tới đó (đã tắt bắc cầu/trụ; cần bậc thang hoặc đường lên từ tầng dưới)", cfg);
            currentTarget = null;
            lastGoal = null;
        }
        if (PlacementExecutor.busy()) return pause();

        scan(w, cfg);
        if (remaining.isEmpty() && extras.isEmpty() && tempGlass.isEmpty() && layerY > topY) {
            stop(blocked.isEmpty() ? "§aHoàn thành!§r" : "Xong phần làm được, còn " + blocked.size() + " ô bị kẹt.");
            return pause();
        }

        // theo dõi tiến triển
        if (layerStuck) {
            int n = 0;
            for (BlockPos k : blocked.keySet()) {
                if (k.getY() == layerY && bp.desired.containsKey(k)) n++;
            }
            stop("§cDừng ở tầng Y=" + layerY + "§r: còn " + n + " ô không làm được nên KHÔNG lên tầng trên. Xử lý rồi gõ /farmbuild start để thử lại.");
            return pause();
        }
        int prog = remaining.size() + extras.size() + tempGlass.size();
        if (prog != lastRemainingSize) {
            lastRemainingSize = prog;
            lastProgressTick = tick;
        }
        if (tick - lastProgressTick > cfg.stallSeconds * 20L) {
            stop("Quá " + cfg.stallSeconds + " giây không tiến triển.");
            return pause();
        }
        if (tick % 20 == 0) {
            bar("FarmBuild tầng " + layerY + ": đã đặt " + placed + " | còn " + remaining.size() + " | thừa " + extras.size() + " | kẹt " + blocked.size());
        }

        // đang phá dở một block
        if (breaking != null) {
            BlockState hs = w.getBlockState(breaking);
            boolean gone = hs.isAir() || hs.isReplaceable();
            if (gone || tick - breakStartedTick > 200 || !inReachCenter(p, breaking, cfg)) {
                if (!gone) fail(breaking, "phá mãi không được", cfg);
                else {
                    extras.remove(breaking);
                    tempGlass.remove(breaking);
                }
                breaking = null;
            } else {
                doBreak(p, breaking, hs);
                return pause();
            }
        }

        Pick pick = choose(p, w, cfg);

        if (pick.place != null) {
            if (tick < nextActionTick) return pause();
            doPlace(p, pick, cfg);
            return pause();
        }
        if (pick.configure != null) {
            if (tick < nextActionTick) return pause();
            doConfigure(p, pick.configure, cfg);
            return pause();
        }
        if (pick.breakPos != null) {
            breaking = pick.breakPos;
            breakStartedTick = tick;
            doBreak(p, breaking, w.getBlockState(breaking));
            return pause();
        }
        if (pick.goalPos != null) {
            return pathTo(p, pick, cfg);
        }

        // không có gì để làm ở thời điểm này
        if (!missing.isEmpty()) {
            stop("Hết vật liệu: " + missingText() + ". Lấy thêm rồi gõ /farmbuild start để tiếp tục.");
        }
        return pause();
    }

    // ================= Lựa chọn việc tiếp theo =================

    private static final class Pick {
        BlockPos place;
        PlacementSolver.Plan plan;
        BlockState want;
        BlockPos configure;
        BlockPos breakPos;
        BlockPos goalPos;
        boolean goalAway;
        /** Nếu đang đặt kính tạm: ô đích mà kính này làm điểm tựa. */
        BlockPos tempFor;

        boolean hasAction() {
            return place != null || configure != null || breakPos != null;
        }

        void setGoal(BlockPos pos, boolean away) {
            if (goalPos == null) {
                goalPos = pos;
                goalAway = away;
            }
        }
    }

    private record Scored(BlockPos pos, double key) {}

    private Pick choose(ClientPlayerEntity p, ClientWorld w, Config cfg) {
        Pick pick = new Pick();
        missing.clear();
        long deadline = System.nanoTime() + (long) (cfg.planBudgetMs * 1_000_000.0);
        BlockPos feet = p.getBlockPos();

        // 00) phá kính tạm khi không còn ô nào cần tựa vào nó
        BlockPos tg = nextTempToRemove(w, p, cfg);
        if (tg != null) {
            if (inReachCenter(p, tg, cfg)) {
                pick.breakPos = tg;
                return pick;
            }
            pick.setGoal(tg, false);
        }

        // 0) dọn block thừa trong tầng hiện tại trước khi đặt
        if (!extras.isEmpty()) {
            BlockPos reachable = null, nearest = null;
            double rd = Double.MAX_VALUE, nd = Double.MAX_VALUE;
            for (BlockPos e : extras) {
                if (retryAt.getOrDefault(e, 0L) > tick) continue;
                Vec3d eye0 = p.getEyePos();
                double ex = e.getX() + 0.5 - eye0.x, ey = e.getY() + 0.5 - eye0.y, ez = e.getZ() + 0.5 - eye0.z;
                double d = ex * ex + ey * ey + ez * ez;
                if (d < nd) {
                    nd = d;
                    nearest = e;
                }
                if (d < rd && inReachCenter(p, e, cfg)) {
                    rd = d;
                    reachable = e;
                }
            }
            if (reachable != null) {
                pick.breakPos = reachable;
                return pick;
            }
            if (nearest != null) pick.setGoal(nearest, false);
        }

        // 1) các ô gần người chơi (đặt "tiện đường"), xếp theo tầng/độ ưu tiên/khoảng cách
        List<Scored> near = new ArrayList<>();
        long r2 = (long) cfg.nearRadius * cfg.nearRadius;
        for (BlockPos pos : remaining) {
            if (!eligible(pos)) continue;
            int dx = pos.getX() - feet.getX();
            int dy = pos.getY() - feet.getY();
            int dz = pos.getZ() - feet.getZ();
            if ((long) dx * dx + (long) dz * dz <= r2 && Math.abs(dy) <= cfg.nearRadius) {
                near.add(new Scored(pos, key(pos, feet)));
            }
        }
        near.sort(Comparator.comparingDouble(Scored::key));
        for (Scored s : near) {
            if (consider(pick, s.pos(), p, w, cfg)) return pick;
            if (System.nanoTime() > deadline) return pick;
        }

        // 2) chưa có gì → xét 40 ô tốt nhất trong toàn bộ công trình
        if (pick.goalPos == null) {
            PriorityQueue<Scored> heap = new PriorityQueue<>(Comparator.comparingDouble((Scored s) -> -s.key()));
            for (BlockPos pos : remaining) {
                if (!eligible(pos)) continue;
                double k = key(pos, feet);
                if (heap.size() < 40) heap.add(new Scored(pos, k));
                else if (k < heap.peek().key()) {
                    heap.poll();
                    heap.add(new Scored(pos, k));
                }
            }
            List<Scored> far = new ArrayList<>(heap);
            far.sort(Comparator.comparingDouble(Scored::key));
            for (Scored s : far) {
                if (consider(pick, s.pos(), p, w, cfg)) return pick;
                if (System.nanoTime() > deadline) return pick;
            }
        }
        return pick;
    }

    /** @return true nếu tìm được một HÀNH ĐỘNG làm ngay được (đặt/chỉnh/phá). Ghi lại đích đi tới vào pick.goalPos. */
    private boolean consider(Pick pick, BlockPos pos, ClientPlayerEntity p, ClientWorld w, Config cfg) {
        BlockState want = bp.desired.get(pos);
        if (want == null) {
            remaining.remove(pos);
            return false;
        }
        if (!w.getChunkManager().isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)) {
            pick.setGoal(pos, false); // đi lại gần để chunk được tải
            whyNot.put(pos, "chunk chưa tải");
            return false;
        }
        BlockState have = w.getBlockState(pos);

        // a) đã đúng loại: chỉ còn chỉnh repeater/comparator
        if (StateRules.baseMatches(have, want)) {
            if (!StateRules.needsConfigure(have, want)) {
                onCorrect(pos);
                remaining.remove(pos);
                return false;
            }
            if (attempts.getOrDefault(pos, 0) >= configCap(want, cfg)) {
                block(pos, "bấm chỉnh trạng thái (delay/mode/mở/bật) không được");
                return false;
            }
            if (inReachCenter(p, pos, cfg)) {
                pick.configure = pos;
                return true;
            }
            pick.setGoal(pos, false);
            return false;
        }

        // b) có block khác chiếm chỗ
        if (!have.isAir() && !have.isReplaceable()) {
            String why = "đang có " + StateRules.id(have.getBlock()) + " chiếm chỗ (cần " + StateRules.id(want.getBlock()) + ")";
            if (!cfg.breakWrong) {
                block(pos, why);
                return false;
            }
            if (attempts.getOrDefault(pos, 0) >= cfg.maxAttempts) {
                block(pos, why);
                return false;
            }
            if (inReachCenter(p, pos, cfg)) {
                pick.breakPos = pos;
                return true;
            }
            pick.setGoal(pos, false);
            return false;
        }

        // c) cần đặt block
        if (attempts.getOrDefault(pos, 0) >= cfg.maxAttempts) {
            block(pos, "đặt " + attempts.get(pos) + " lần vẫn không ra đúng trạng thái");
            return false;
        }
        if (cfg.breakWrong && StateRules.hasLowerHalf(want)) {
            BlockPos up = pos.up();
            BlockState uh = w.getBlockState(up);
            if (!uh.isAir() && !uh.isReplaceable() && uh.getBlock() != want.getBlock()) {
                if (attempts.getOrDefault(up, 0) >= cfg.maxAttempts) {
                    block(pos, "ô phía trên bị vướng, phá không được");
                    return false;
                }
                if (inReachCenter(p, up, cfg)) {
                    pick.breakPos = up;
                    return true;
                }
                pick.setGoal(up, false);
                return false;
            }
        }
        Item item = want.getBlock().asItem();
        if (!Stock.has(p, item)) {
            missing.merge(item, 1, Integer::sum);
            return false;
        }
        PlacementSolver.Result r = PlacementSolver.solve(mc, pos, want, cfg);
        if (r.best == null) {
            if (r.entityBlocked) {
                pick.setGoal(pos, true);
                return false;
            }
            if (cfg.tempSupport && tempUsed.getOrDefault(pos, 0) < 6
                && (noSolve.getOrDefault(pos, 0) >= 3 || !neighborPending(pos))) {
                if (!Stock.has(p, Items.GLASS)) {
                    missing.merge(Items.GLASS, 1, Integer::sum);
                } else {
                    GlassPick gp = nextGlass(pos, 3, w, cfg);
                    if (gp != null) {
                        if (gp.plan().reachable()) {
                            pick.place = gp.cell();
                            pick.plan = gp.plan();
                            pick.want = GLASS;
                            pick.tempFor = pos;
                            return true;
                        }
                        pick.setGoal(pos, false);
                        return false;
                    }
                }
            }
            String why = "chưa có block để tựa / không có cách đặt đúng hướng";
            if (noSolve.merge(pos, 1, Integer::sum) >= 15) block(pos, why);
            else delay(pos, 20, why);
            return false;
        }
        if (r.best.reachable()) {
            pick.place = pos;
            pick.plan = r.best;
            pick.want = want;
            return true;
        }
        pick.setGoal(pos, false);
        return false;
    }

    private record GlassPick(BlockPos cell, PlacementSolver.Plan plan) {}

    private static final Direction[] GLASS_ORDER = {
        Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP
    };

    private boolean neighborPending(BlockPos pos) {
        for (Direction d : Direction.values()) {
            if (remaining.contains(pos.offset(d))) return true;
        }
        return false;
    }

    private boolean tempCellOk(BlockPos sp, ClientWorld w) {
        if (!w.getChunkManager().isChunkLoaded(sp.getX() >> 4, sp.getZ() >> 4)) return false;
        BlockState st = w.getBlockState(sp);
        if (!st.isAir() && !st.isReplaceable()) return false;
        if (bp.desired.containsKey(sp) || bp.keep.contains(sp)) return false;
        return mc.player == null || !new Box(sp).intersects(mc.player.getBoundingBox());
    }

    /** Tìm ô trống cạnh {@code need} (hoặc chuỗi tới 3 ô) để đặt kính làm điểm tựa; trả về ô kính đặt được NGAY BÂY GIỜ. */
    private GlassPick nextGlass(BlockPos need, int depth, ClientWorld w, Config cfg) {
        GlassPick fallback = null;
        for (Direction d : GLASS_ORDER) {
            BlockPos sp = need.offset(d);
            if (!tempCellOk(sp, w)) continue;
            PlacementSolver.Result r = PlacementSolver.solve(mc, sp, GLASS, cfg);
            if (r.best == null) continue;
            if (r.best.reachable()) return new GlassPick(sp, r.best);
            if (fallback == null) fallback = new GlassPick(sp, r.best);
        }
        if (fallback != null) return fallback;
        if (depth > 1) {
            for (Direction d : GLASS_ORDER) {
                BlockPos sp = need.offset(d);
                if (!tempCellOk(sp, w)) continue;
                GlassPick g = nextGlass(sp, depth - 1, w, cfg);
                if (g != null) return g;
            }
        }
        return null;
    }

    /** Kính tạm cần phá: không còn ô cần-đặt nào sát bên (hoặc quá 60 giây). Trả về cái gần nhất. */
    private BlockPos nextTempToRemove(ClientWorld w, ClientPlayerEntity p, Config cfg) {
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        Iterator<Map.Entry<BlockPos, Long>> it = tempGlass.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<BlockPos, Long> e = it.next();
            BlockPos g = e.getKey();
            if (blocked.containsKey(g)) {
                it.remove();
                continue;
            }
            if (!w.getChunkManager().isChunkLoaded(g.getX() >> 4, g.getZ() >> 4)) continue;
            if (!w.getBlockState(g).isOf(Blocks.GLASS)) {
                if (tick - e.getValue() > 15) it.remove();
                continue;
            }
            boolean needed = false;
            for (Direction d : Direction.values()) {
                if (remaining.contains(g.offset(d))) {
                    needed = true;
                    break;
                }
            }
            if (needed && tick - e.getValue() < 1200) continue;
            if (retryAt.getOrDefault(g, 0L) > tick) continue;
            double gx = g.getX() + 0.5 - p.getX(), gy = g.getY() + 0.5 - p.getY(), gz = g.getZ() + 0.5 - p.getZ();
            double d2 = gx * gx + gy * gy + gz * gz;
            if (d2 < bd) {
                bd = d2;
                best = g;
            }
        }
        return best;
    }

    private boolean eligible(BlockPos pos) {
        return pos.getY() == layerY && verifyUntil.getOrDefault(pos, 0L) <= tick && retryAt.getOrDefault(pos, 0L) <= tick;
    }

    /** Thấp = làm trước: nền → máy → linh kiện, từ tầng thấp lên cao, rồi gần trước. */
    private double key(BlockPos pos, BlockPos feet) {
        BlockState s = bp.desired.get(pos);
        int tier = tierCache.computeIfAbsent(s, StateRules::tier);
        ClientWorld cw = mc.world;
        if (cw != null && StateRules.baseMatches(cw.getBlockState(pos), s)) tier = 3; // chỉ còn bấm chỉnh → làm cuối tầng
        double dx = pos.getX() - feet.getX();
        double dy = pos.getY() - feet.getY();
        double dz = pos.getZ() - feet.getZ();
        return tier * 100000.0 + (pos.getY() - bp.minY) * 200.0 + Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private boolean inReachCenter(ClientPlayerEntity p, BlockPos pos, Config cfg) {
        Vec3d eye = p.getEyePos();
        double dx = pos.getX() + 0.5 - eye.x;
        double dy = pos.getY() + 0.5 - eye.y;
        double dz = pos.getZ() + 0.5 - eye.z;
        double reach = Math.max(1.0, cfg.reach - 0.5);
        return dx * dx + dy * dy + dz * dz <= reach * reach;
    }

    private static int configCap(BlockState want, Config cfg) {
        return StateRules.id(want.getBlock()).equals("note_block") ? 30 : cfg.maxAttempts + 3;
    }

    // ================= Hành động =================

    private void doPlace(ClientPlayerEntity p, Pick pick, Config cfg) {
        BlockPos pos = pick.place;
        PlacementSolver.Plan plan = pick.plan;
        Item item = pick.want.getBlock().asItem();
        int slot = Stock.ensureHotbar(mc, item);
        if (slot < 0) {
            missing.merge(item, 1, Integer::sum);
            delay(pos, 20, "thiếu vật liệu");
            return;
        }
        BlockHitResult hit = new BlockHitResult(plan.hit(), plan.side(), plan.support(), false);
        PlacementExecutor.queue(new PlacementExecutor.Job(pos, hit, plan.yaw(), plan.pitch(), plan.spoof(), plan.sneak(), slot));
        verifyUntil.put(pos, tick + 6);
        attempts.merge(pos, 1, Integer::sum);
        if (pick.tempFor != null) {
            tempGlass.put(pos.toImmutable(), tick);
            tempUsed.merge(pick.tempFor, 1, Integer::sum);
            retryAt.put(pick.tempFor, tick + 4); // đợi kính hiện ra rồi mới đặt block chính
            whyNot.put(pick.tempFor, "đang đặt kính tạm làm điểm tựa");
        }
        nextActionTick = tick + Math.max(1, cfg.placeDelay);
        currentTarget = null;
    }

    /** Click phải (không sneak) vào repeater/comparator để xoay delay/mode. */
    private void doConfigure(ClientPlayerEntity p, BlockPos pos, Config cfg) {
        Vec3d hv = new Vec3d(pos.getX() + 0.5, pos.getY() + 0.1, pos.getZ() + 0.5);
        BlockHitResult hit = new BlockHitResult(hv, Direction.UP, pos, false);
        int slot = p.getInventory().getSelectedSlot();
        PlacementExecutor.queue(new PlacementExecutor.Job(pos, hit, p.getYaw(), p.getPitch(), false, false, slot));
        verifyUntil.put(pos, tick + 3);
        attempts.merge(pos, 1, Integer::sum);
        nextActionTick = tick + Math.max(1, cfg.placeDelay);
    }

    private void doBreak(ClientPlayerEntity p, BlockPos pos, BlockState state) {
        if (mc.interactionManager == null) return;
        selectTool(p, state);
        Vec3d eye = p.getEyePos();
        Direction face = faceToward(eye.x - (pos.getX() + 0.5), eye.y - (pos.getY() + 0.5), eye.z - (pos.getZ() + 0.5));
        mc.interactionManager.updateBlockBreakingProgress(pos, face);
        p.swingHand(Hand.MAIN_HAND);
    }

    private static Direction faceToward(double dx, double dy, double dz) {
        double ax = Math.abs(dx), ay = Math.abs(dy), az = Math.abs(dz);
        if (ay >= ax && ay >= az) return dy > 0 ? Direction.UP : Direction.DOWN;
        if (ax >= az) return dx > 0 ? Direction.EAST : Direction.WEST;
        return dz > 0 ? Direction.SOUTH : Direction.NORTH;
    }

    private void selectTool(ClientPlayerEntity p, BlockState st) {
        if (p.isCreative()) return;
        PlayerInventory inv = p.getInventory();
        int best = inv.getSelectedSlot();
        float bestSpeed = inv.getStack(best).getMiningSpeedMultiplier(st);
        for (int i = 0; i < 9; i++) {
            float s = inv.getStack(i).getMiningSpeedMultiplier(st);
            if (s > bestSpeed + 0.01f) {
                best = i;
                bestSpeed = s;
            }
        }
        if (best != inv.getSelectedSlot()) inv.setSelectedSlot(best);
    }

    private PathingCommand pathTo(ClientPlayerEntity p, Pick pick, Config cfg) {
        BlockPos tgt = pick.goalPos;
        int att = attempts.getOrDefault(tgt, 0);
        int range = Math.max(1, cfg.goalRange - att);
        Goal g = pick.goalAway ? new GoalInverted(new GoalNear(tgt, 1)) : new GoalNear(tgt, range);
        boolean changed = !g.equals(lastGoal);
        currentTarget = tgt;

        // đã tới đích mà không đặt được → coi là thất bại lần này, lần sau tới gần hơn
        if (!changed && g.isInGoal(p.getBlockPos()) && !baritone.getPathingBehavior().isPathing()) {
            arrivedTicks++;
            if (arrivedTicks > 12) {
                arrivedTicks = 0;
                currentTarget = null;
                lastGoal = null;
                if (pick.goalAway) {
                    delay(tgt, 10, "đang đứng chắn chỗ đặt");
                } else {
                    fail(tgt, "tới nơi rồi nhưng không có góc đặt/nhìn thấy phù hợp", cfg);
                }
                return pause();
            }
        } else {
            arrivedTicks = 0;
        }
        lastGoal = g;
        return new PathingCommand(g, changed ? PathingCommandType.CANCEL_AND_SET_GOAL : PathingCommandType.SET_GOAL_AND_PATH);
    }

    private static PathingCommand pause() {
        return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
    }

    // ================= Quét thế giới =================

    private void scan(ClientWorld w, Config cfg) {
        int interval = remaining.size() <= 64 ? 2 : cfg.scanInterval;
        if (tick - lastScan < interval) return;
        lastScan = tick;

        // định kỳ quét lại toàn bộ bản vẽ (phát hiện block bị phá/đổi)
        if (tick - lastFull >= 200) {
            lastFull = tick;
            for (Map.Entry<BlockPos, BlockState> e : bp.desired.entrySet()) {
                BlockPos pos = e.getKey();
                if (remaining.contains(pos)) continue;
                if (!w.getChunkManager().isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)) {
                    // chunk chưa tải: coi như chưa xong (không được báo "hoàn thành" nhầm), sẽ đi tới đó sau
                    if (!blocked.containsKey(pos)) remaining.add(pos);
                    continue;
                }
                BlockState have = w.getBlockState(pos);
                boolean ok = StateRules.baseMatches(have, e.getValue()) && !StateRules.needsConfigure(have, e.getValue());
                if (ok) {
                    if (blocked.remove(pos) != null) onCorrect(pos);
                } else if (!blocked.containsKey(pos)) {
                    remaining.add(pos);
                }
            }
        }

        Iterator<BlockPos> it = remaining.iterator();
        while (it.hasNext()) {
            BlockPos pos = it.next();
            BlockState want = bp.desired.get(pos);
            if (want == null) {
                it.remove();
                continue;
            }
            if (!w.getChunkManager().isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)) continue;
            BlockState have = w.getBlockState(pos);
            if (StateRules.baseMatches(have, want) && !StateRules.needsConfigure(have, want)) {
                onCorrect(pos);
                it.remove();
            }
        }
        updateLayer(w, cfg);
    }

    /** Chọn tầng đang làm: tầng thấp nhất còn block cần đặt hoặc còn block thừa; xong hết thì layerY > topY. */
    private void updateLayer(ClientWorld w, Config cfg) {
        int minRem = Integer.MAX_VALUE;
        for (BlockPos pos : remaining) {
            if (pos.getY() < minRem) minRem = pos.getY();
        }
        layerStuck = false;
        if (minRem < layerY) layerY = minRem;
        while (layerY <= topY) {
            computeExtras(w, cfg);
            if (minRem == layerY || !extras.isEmpty()) break;
            if (hasBlockedAt(layerY)) {
                layerStuck = true;
                break;
            }
            layerY++;
        }
        if (layerY <= topY && layerY != lastAnnouncedLayer) {
            lastAnnouncedLayer = layerY;
            say("Xây tầng Y=§e" + layerY + "§r (" + Math.max(0, layerY - bp.boxMinY() + 1) + "/" + (topY - bp.boxMinY() + 1) + ").");
        }
        if (layerY > topY) extras.clear();
    }

    private boolean hasBlockedAt(int y) {
        for (BlockPos k : blocked.keySet()) {
            if (k.getY() == y && bp.desired.containsKey(k)) return true;
        }
        return false;
    }

    /** Liệt kê block thừa (không có trong bản vẽ, không phải thứ tự mọc) trong vùng bản vẽ ở tầng layerY. */
    private void computeExtras(ClientWorld w, Config cfg) {
        extras.clear();
        if (!cfg.clearExtra) return;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int[] b : bp.boxes) {
            if (layerY < b[1] || layerY > b[4]) continue;
            for (int x = b[0]; x <= b[3]; x++) {
                for (int z = b[2]; z <= b[5]; z++) {
                    if (!w.getChunkManager().isChunkLoaded(x >> 4, z >> 4)) continue;
                    m.set(x, layerY, z);
                    BlockState have = w.getBlockState(m);
                    if (have.isAir() || have.isReplaceable()) continue;
                    if (bp.desired.containsKey(m) || bp.keep.contains(m) || blocked.containsKey(m) || tempGlass.containsKey(m)) continue;
                    extras.add(m.toImmutable());
                }
            }
        }
    }

    private void onCorrect(BlockPos pos) {
        if (attempts.remove(pos) != null) placed++;
        else alreadyCorrect++;
        retryAt.remove(pos);
        verifyUntil.remove(pos);
        whyNot.remove(pos);
        blocked.remove(pos);
        noSolve.remove(pos);
    }

    // ================= Thất bại / kẹt =================

    private void delay(BlockPos pos, int ticks, String why) {
        retryAt.put(pos, tick + ticks);
        whyNot.put(pos, why);
    }

    private void fail(BlockPos pos, String why, Config cfg) {
        int a = attempts.merge(pos, 1, Integer::sum);
        if (a >= cfg.maxAttempts) block(pos, why);
        else delay(pos, 40L * a > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) (40L * a), why);
    }

    private void block(BlockPos pos, String why) {
        remaining.remove(pos);
        blocked.put(pos.toImmutable(), why);
    }

    // ================= Cài đặt Baritone =================

    private void applyBaritoneSettings() {
        Config cfg = Config.get();
        Settings s = BaritoneAPI.getSettings();
        savedAllowBreak = s.allowBreak.value;
        savedAllowPlace = s.allowPlace.value;
        s.allowBreak.value = cfg.allowBaritoneBreak;
        s.allowPlace.value = cfg.allowScaffold;
    }

    private void restoreBaritoneSettings() {
        Settings s = BaritoneAPI.getSettings();
        if (savedAllowBreak != null) s.allowBreak.value = savedAllowBreak;
        if (savedAllowPlace != null) s.allowPlace.value = savedAllowPlace;
        savedAllowBreak = null;
        savedAllowPlace = null;
    }

    // ================= Thông báo =================

    private void resetState() {
        remaining.clear();
        attempts.clear();
        retryAt.clear();
        verifyUntil.clear();
        whyNot.clear();
        blocked.clear();
        missing.clear();
        tick = 0;
        lastScan = -1000;
        lastFull = -1000;
        nextActionTick = 0;
        lastProgressTick = 0;
        lastRemainingSize = -1;
        placed = 0;
        alreadyCorrect = 0;
        currentTarget = null;
        lastGoal = null;
        arrivedTicks = 0;
        breaking = null;
        noSolve.clear();
        tempGlass.clear();
        tempUsed.clear();
        extras.clear();
        layerStuck = false;
        if (bp != null) {
            bp.ensureBox();
            layerY = bp.boxMinY();
            topY = bp.boxMaxY();
        }
        lastAnnouncedLayer = Integer.MIN_VALUE;
    }

    private String missingText() {
        StringBuilder sb = new StringBuilder();
        int n = 0;
        for (Map.Entry<Item, Integer> e : missing.entrySet()) {
            if (n++ > 0) sb.append(", ");
            if (n > 10) {
                sb.append("...");
                break;
            }
            sb.append(e.getKey().getName().getString()).append(" x").append(e.getValue());
        }
        return sb.toString();
    }

    private void report() {
        say("Đã đặt " + placed + " block (" + alreadyCorrect + " ô vốn đã đúng), còn " + remaining.size() + " ô.");
        if (!tempGlass.isEmpty()) say("§eCòn " + tempGlass.size() + " kính tạm chưa phá — tự phá giúp nhé.");
        if (!blocked.isEmpty()) {
            say("§cKẹt " + blocked.size() + " ô§r (hiện tối đa 8):");
            int n = 0;
            for (Map.Entry<BlockPos, String> e : blocked.entrySet()) {
                if (n++ >= 8) break;
                BlockPos b = e.getKey();
                BlockState st = bp.desired.get(b);
                say(" - " + b.getX() + " " + b.getY() + " " + b.getZ() + " " + (st == null ? "?" : StateRules.id(st.getBlock())) + ": " + e.getValue());
            }
        }
        int shown = 0;
        for (BlockPos pos : remaining) {
            if (shown == 0) say("Các ô chưa làm được (tối đa 5):");
            if (shown++ >= 5) break;
            BlockState st = bp.desired.get(pos);
            say(" - " + pos.getX() + " " + pos.getY() + " " + pos.getZ() + " " + (st == null ? "?" : StateRules.id(st.getBlock()))
                + ": " + whyNot.getOrDefault(pos, "chưa tới lượt"));
        }
        if (bp.skippedFluid + bp.skippedNoItem + bp.skippedUnknown + bp.skippedDependent > 0) {
            say("Bỏ qua khi nạp: " + bp.skippedFluid + " ô nước/dung nham (đổ bằng xô), " + bp.skippedNoItem
                + " ô không có item (piston head, lửa...), " + bp.skippedUnknown + " block lạ, "
                + bp.skippedDependent + " nửa trên cửa/giường (tự có khi đặt nửa dưới).");
        }
    }

    private void say(String msg) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("§b[FarmBuild]§r " + msg), false);
    }

    private void bar(String msg) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(msg), true);
    }
}
