package com.farmbuild.process;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import baritone.api.Settings;
import baritone.api.pathing.goals.Goal;
import baritone.api.pathing.goals.GoalInverted;
import baritone.api.pathing.goals.GoalNear;
import baritone.api.process.IBaritoneProcess;
import baritone.api.process.PathingCommand;
import baritone.api.process.PathingCommandType;
import com.farmbuild.Config;
import com.farmbuild.place.PlacementExecutor;
import com.farmbuild.place.PlacementSolver;
import com.farmbuild.place.StateRules;
import com.farmbuild.place.Stock;
import com.farmbuild.schem.Blueprint;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

/**
 * Tiến trình xây dựng, cắm thẳng vào hệ thống process của Baritone (giống BuilderProcess của chính nó):
 *  - mỗi tick: so bản vẽ với thế giới → danh sách ô còn sai;
 *  - có ô đặt được ngay trong tầm tay → đặt (kiểu Easy Redstone) và yêu cầu Baritone tạm dừng;
 *  - không có → giao cho Baritone một GoalNear tới ô tốt nhất kế tiếp (Baritone lo bắc cầu/leo/nhảy/tránh nguy hiểm).
 */
public final class FarmProcess implements IBaritoneProcess {
    private final IBaritone baritone;
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private Blueprint bp;
    private boolean running;

    private final Set<BlockPos> remaining = new HashSet<>();
    private final Map<BlockPos, Integer> attempts = new HashMap<>();
    private final Map<BlockPos, Long> retryAt = new HashMap<>();
    private final Map<BlockPos, Long> verifyUntil = new HashMap<>();
    private final Map<BlockPos, String> whyNot = new HashMap<>();
    private final Map<BlockPos, String> blocked = new LinkedHashMap<>();
    private final Map<Item, Integer> missing = new LinkedHashMap<>();
    private final Map<BlockState, Integer> tierCache = new IdentityHashMap<>();

    private long tick;
    private long lastScan;
    private long lastFull;
    private long nextActionTick;
    private long lastProgressTick;
    private long breakStartedTick;
    private int lastRemainingSize;
    private int placed;
    private int alreadyCorrect;
    private BlockPos currentTarget;
    private Goal lastGoal;
    private int arrivedTicks;
    private BlockPos breaking;

    private Boolean savedAllowBreak;
    private Boolean savedAllowPlace;

    public FarmProcess(IBaritone baritone) {
        this.baritone = baritone;
    }

    // ================= API cho lệnh / phím =================

    public void setBlueprint(Blueprint blueprint) {
        if (running) stop("Nạp bản vẽ mới nên dừng bản cũ.");
        this.bp = blueprint;
        resetState();
    }

    public Blueprint blueprint() {
        return bp;
    }

    public boolean isRunning() {
        return running;
    }

    /** @return null nếu OK, hoặc thông báo lỗi. */
    public String start() {
        if (bp == null) return "Chưa nạp bản vẽ. Dùng: /farmbuild load <tên file>";
        if (mc.player == null || mc.world == null) return "Chưa vào thế giới.";
        resetState();
        applyBaritoneSettings();
        try {
            baritone.getPathingBehavior().cancelEverything();
        } catch (Throwable ignored) {
        }
        running = true;
        say("Bắt đầu xây §e" + bp.name + "§r (" + bp.size() + " block). Dừng bằng phím K hoặc /farmbuild stop.");
        return null;
    }

    public void stop(String reason) {
        boolean was = running;
        running = false;
        PlacementExecutor.clear();
        restoreBaritoneSettings();
        try {
            baritone.getPathingBehavior().cancelEverything();
        } catch (Throwable ignored) {
        }
        currentTarget = null;
        lastGoal = null;
        breaking = null;
        if (was) {
            say(reason);
            report();
        }
    }

    public String status() {
        if (bp == null) return "Chưa nạp bản vẽ.";
        return (running ? "§aĐang xây§r " : "§7Đang dừng§r ") + bp.name + ": đã đặt " + placed + ", còn " + remaining.size()
            + " ô, kẹt " + blocked.size() + ".";
    }

    // ================= IBaritoneProcess =================

    @Override
    public boolean isActive() {
        return running;
    }

    @Override
    public boolean isTemporary() {
        return false;
    }

    @Override
    public void onLostControl() {
        lastGoal = null;
        PlacementExecutor.clear();
    }

    @Override
    public String displayName0() {
        return "FarmBuild " + (bp == null ? "" : bp.name);
    }

    @Override
    public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null || bp == null) {
            stop("Mất kết nối với thế giới.");
            return pause();
        }
        Config cfg = Config.get();
        tick++;

        if (calcFailed && currentTarget != null) {
            fail(currentTarget, "Baritone không tìm được đường tới đó", cfg);
            currentTarget = null;
            lastGoal = null;
        }
        if (PlacementExecutor.busy()) return pause();

        scan(w, cfg);
        if (remaining.isEmpty()) {
            stop(blocked.isEmpty() ? "§aHoàn thành!§r" : "Xong phần làm được, còn " + blocked.size() + " ô bị kẹt.");
            return pause();
        }

        // theo dõi tiến triển
        if (remaining.size() != lastRemainingSize) {
            lastRemainingSize = remaining.size();
            lastProgressTick = tick;
        }
        if (tick - lastProgressTick > cfg.stallSeconds * 20L) {
            stop("Quá " + cfg.stallSeconds + " giây không tiến triển.");
            return pause();
        }
        if (tick % 20 == 0) {
            bar("FarmBuild: đã đặt " + placed + " | còn " + remaining.size() + " | kẹt " + blocked.size());
        }

        // đang phá dở một block
        if (breaking != null) {
            BlockState hs = w.getBlockState(breaking);
            boolean gone = hs.isAir() || hs.isReplaceable();
            if (gone || tick - breakStartedTick > 200 || !inReachCenter(p, breaking, cfg)) {
                if (!gone) fail(breaking, "phá mãi không được", cfg);
                breaking = null;
            } else {
                doBreak(p, breaking, hs);
                return pause();
            }
        }

        Pick pick = choose(p, w, cfg);

        if (pick.place != null) {
            if (tick < nextActionTick) return pause();
            doPlace(p, pick, cfg);
            return pause();
        }
        if (pick.configure != null) {
            if (tick < nextActionTick) return pause();
            doConfigure(p, pick.configure, cfg);
            return pause();
        }
        if (pick.breakPos != null) {
            breaking = pick.breakPos;
            breakStartedTick = tick;
            doBreak(p, breaking, w.getBlockState(breaking));
            return pause();
        }
        if (pick.goalPos != null) {
            return pathTo(p, pick, cfg);
        }

        // không có gì để làm ở thời điểm này
        if (!missing.isEmpty()) {
            stop("Hết vật liệu: " + missingText() + ". Lấy thêm rồi gõ /farmbuild start để tiếp tục.");
        }
        return pause();
    }

    // ================= Lựa chọn việc tiếp theo =================

    private static final class Pick {
        BlockPos place;
        PlacementSolver.Plan plan;
        BlockState want;
        BlockPos configure;
        BlockPos breakPos;
        BlockPos goalPos;
        boolean goalAway;

        boolean hasAction() {
            return place != null || configure != null || breakPos != null;
        }

        void setGoal(BlockPos pos, boolean away) {
            if (goalPos == null) {
                goalPos = pos;
                goalAway = away;
            }
        }
    }

    private record Scored(BlockPos pos, double key) {}

    private Pick choose(ClientPlayerEntity p, ClientWorld w, Config cfg) {
        Pick pick = new Pick();
        missing.clear();
        long deadline = System.nanoTime() + (long) (cfg.planBudgetMs * 1_000_000.0);
        BlockPos feet = p.getBlockPos();

        // 1) các ô gần người chơi (đặt "tiện đường"), xếp theo tầng/độ ưu tiên/khoảng cách
        List<Scored> near = new ArrayList<>();
        long r2 = (long) cfg.nearRadius * cfg.nearRadius;
        for (BlockPos pos : remaining) {
            if (!eligible(pos)) continue;
            int dx = pos.getX() - feet.getX();
            int dy = pos.getY() - feet.getY();
            int dz = pos.getZ() - feet.getZ();
            if ((long) dx * dx + (long) dz * dz <= r2 && Math.abs(dy) <= cfg.nearRadius) {
                near.add(new Scored(pos, key(pos, feet)));
            }
        }
        near.sort(Comparator.comparingDouble(Scored::key));
        for (Scored s : near) {
            if (consider(pick, s.pos(), p, w, cfg)) return pick;
            if (System.nanoTime() > deadline) return pick;
        }

        // 2) chưa có gì → xét 40 ô tốt nhất trong toàn bộ công trình
        if (pick.goalPos == null) {
            PriorityQueue<Scored> heap = new PriorityQueue<>(Comparator.comparingDouble((Scored s) -> -s.key()));
            for (BlockPos pos : remaining) {
                if (!eligible(pos)) continue;
                double k = key(pos, feet);
                if (heap.size() < 40) heap.add(new Scored(pos, k));
                else if (k < heap.peek().key()) {
                    heap.poll();
                    heap.add(new Scored(pos, k));
                }
            }
            List<Scored> far = new ArrayList<>(heap);
            far.sort(Comparator.comparingDouble(Scored::key));
            for (Scored s : far) {
                if (consider(pick, s.pos(), p, w, cfg)) return pick;
                if (System.nanoTime() > deadline) return pick;
            }
        }
        return pick;
    }

    /** @return true nếu tìm được một HÀNH ĐỘNG làm ngay được (đặt/chỉnh/phá). Ghi lại đích đi tới vào pick.goalPos. */
    private boolean consider(Pick pick, BlockPos pos, ClientPlayerEntity p, ClientWorld w, Config cfg) {
        BlockState want = bp.desired.get(pos);
        if (want == null) {
            remaining.remove(pos);
            return false;
        }
        if (!w.getChunkManager().isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)) {
            pick.setGoal(pos, false); // đi lại gần để chunk được tải
            whyNot.put(pos, "chunk chưa tải");
            return false;
        }
        BlockState have = w.getBlockState(pos);

        // a) đã đúng loại: chỉ còn chỉnh repeater/comparator
        if (StateRules.baseMatches(have, want)) {
            if (!StateRules.needsConfigure(have, want)) {
                onCorrect(pos);
                remaining.remove(pos);
                return false;
            }
            if (attempts.getOrDefault(pos, 0) >= cfg.maxAttempts + 3) {
                block(pos, "chỉnh delay/mode không được");
                return false;
            }
            if (inReachCenter(p, pos, cfg)) {
                pick.configure = pos;
                return true;
            }
            pick.setGoal(pos, false);
            return false;
        }

        // b) có block khác chiếm chỗ
        if (!have.isAir() && !have.isReplaceable()) {
            String why = "đang có " + StateRules.id(have.getBlock()) + " chiếm chỗ (cần " + StateRules.id(want.getBlock()) + ")";
            if (!cfg.breakWrong) {
                block(pos, why);
                return false;
            }
            if (attempts.getOrDefault(pos, 0) >= cfg.maxAttempts) {
                block(pos, why);
                return false;
            }
            if (inReachCenter(p, pos, cfg)) {
                pick.breakPos = pos;
                return true;
            }
            pick.setGoal(pos, false);
            return false;
        }

        // c) cần đặt block
        if (attempts.getOrDefault(pos, 0) >= cfg.maxAttempts) {
            block(pos, "đặt " + attempts.get(pos) + " lần vẫn không ra đúng trạng thái");
            return false;
        }
        Item item = want.getBlock().asItem();
        if (!Stock.has(p, item)) {
            missing.merge(item, 1, Integer::sum);
            return false;
        }
        PlacementSolver.Result r = PlacementSolver.solve(mc, pos, want, cfg);
        if (r.best == null) {
            if (r.entityBlocked) {
                pick.setGoal(pos, true);
                return false;
            }
            delay(pos, 20, "chưa có block để tựa / không có cách đặt đúng hướng");
            return false;
        }
        if (r.best.reachable()) {
            pick.place = pos;
            pick.plan = r.best;
            pick.want = want;
            return true;
        }
        pick.setGoal(pos, false);
        return false;
    }

    private boolean eligible(BlockPos pos) {
        return verifyUntil.getOrDefault(pos, 0L) <= tick && retryAt.getOrDefault(pos, 0L) <= tick;
    }

    /** Thấp = làm trước: nền → máy → linh kiện, từ tầng thấp lên cao, rồi gần trước. */
    private double key(BlockPos pos, BlockPos feet) {
        BlockState s = bp.desired.get(pos);
        int tier = tierCache.computeIfAbsent(s, StateRules::tier);
        double dx = pos.getX() - feet.getX();
        double dy = pos.getY() - feet.getY();
        double dz = pos.getZ() - feet.getZ();
        return tier * 100000.0 + (pos.getY() - bp.minY) * 200.0 + Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private boolean inReachCenter(ClientPlayerEntity p, BlockPos pos, Config cfg) {
        Vec3d eye = p.getEyePos();
        double dx = pos.getX() + 0.5 - eye.x;
        double dy = pos.getY() + 0.5 - eye.y;
        double dz = pos.getZ() + 0.5 - eye.z;
        double reach = Math.max(1.0, cfg.reach - 0.5);
        return dx * dx + dy * dy + dz * dz <= reach * reach;
    }

    // ================= Hành động =================

    private void doPlace(ClientPlayerEntity p, Pick pick, Config cfg) {
        BlockPos pos = pick.place;
        PlacementSolver.Plan plan = pick.plan;
        Item item = pick.want.getBlock().asItem();
        int slot = Stock.ensureHotbar(mc, item);
        if (slot < 0) {
            missing.merge(item, 1, Integer::sum);
            delay(pos, 20, "thiếu vật liệu");
            return;
        }
        BlockHitResult hit = new BlockHitResult(plan.hit(), plan.side(), plan.support(), false);
        PlacementExecutor.queue(new PlacementExecutor.Job(pos, hit, plan.yaw(), plan.pitch(), plan.spoof(), plan.sneak(), slot));
        verifyUntil.put(pos, tick + 6);
        attempts.merge(pos, 1, Integer::sum);
        nextActionTick = tick + Math.max(1, cfg.placeDelay);
        currentTarget = null;
    }

    /** Click phải (không sneak) vào repeater/comparator để xoay delay/mode. */
    private void doConfigure(ClientPlayerEntity p, BlockPos pos, Config cfg) {
        Vec3d hv = new Vec3d(pos.getX() + 0.5, pos.getY() + 0.1, pos.getZ() + 0.5);
        BlockHitResult hit = new BlockHitResult(hv, Direction.UP, pos, false);
        int slot = p.getInventory().getSelectedSlot();
        PlacementExecutor.queue(new PlacementExecutor.Job(pos, hit, p.getYaw(), p.getPitch(), false, false, slot));
        verifyUntil.put(pos, tick + 3);
        attempts.merge(pos, 1, Integer::sum);
        nextActionTick = tick + Math.max(1, cfg.placeDelay);
    }

    private void doBreak(ClientPlayerEntity p, BlockPos pos, BlockState state) {
        if (mc.interactionManager == null) return;
        selectTool(p, state);
        Vec3d eye = p.getEyePos();
        Direction face = faceToward(eye.x - (pos.getX() + 0.5), eye.y - (pos.getY() + 0.5), eye.z - (pos.getZ() + 0.5));
        mc.interactionManager.updateBlockBreakingProgress(pos, face);
        p.swingHand(Hand.MAIN_HAND);
    }

    private static Direction faceToward(double dx, double dy, double dz) {
        double ax = Math.abs(dx), ay = Math.abs(dy), az = Math.abs(dz);
        if (ay >= ax && ay >= az) return dy > 0 ? Direction.UP : Direction.DOWN;
        if (ax >= az) return dx > 0 ? Direction.EAST : Direction.WEST;
        return dz > 0 ? Direction.SOUTH : Direction.NORTH;
    }

    private void selectTool(ClientPlayerEntity p, BlockState st) {
        if (p.isCreative()) return;
        PlayerInventory inv = p.getInventory();
        int best = inv.getSelectedSlot();
        float bestSpeed = inv.getStack(best).getMiningSpeedMultiplier(st);
        for (int i = 0; i < 9; i++) {
            float s = inv.getStack(i).getMiningSpeedMultiplier(st);
            if (s > bestSpeed + 0.01f) {
                best = i;
                bestSpeed = s;
            }
        }
        if (best != inv.getSelectedSlot()) inv.setSelectedSlot(best);
    }

    private PathingCommand pathTo(ClientPlayerEntity p, Pick pick, Config cfg) {
        BlockPos tgt = pick.goalPos;
        int att = attempts.getOrDefault(tgt, 0);
        int range = Math.max(1, cfg.goalRange - att);
        Goal g = pick.goalAway ? new GoalInverted(new GoalNear(tgt, 1)) : new GoalNear(tgt, range);
        boolean changed = !g.equals(lastGoal);
        currentTarget = tgt;

        // đã tới đích mà không đặt được → coi là thất bại lần này, lần sau tới gần hơn
        if (!changed && g.isInGoal(p.getBlockPos()) && !baritone.getPathingBehavior().isPathing()) {
            arrivedTicks++;
            if (arrivedTicks > 12) {
                arrivedTicks = 0;
                currentTarget = null;
                lastGoal = null;
                if (pick.goalAway) {
                    delay(tgt, 10, "đang đứng chắn chỗ đặt");
                } else {
                    fail(tgt, "tới nơi rồi nhưng không có góc đặt/nhìn thấy phù hợp", cfg);
                }
                return pause();
            }
        } else {
            arrivedTicks = 0;
        }
        lastGoal = g;
        return new PathingCommand(g, changed ? PathingCommandType.CANCEL_AND_SET_GOAL : PathingCommandType.SET_GOAL_AND_PATH);
    }

    private static PathingCommand pause() {
        return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
    }

    // ================= Quét thế giới =================

    private void scan(ClientWorld w, Config cfg) {
        if (tick - lastScan < cfg.scanInterval) return;
        lastScan = tick;

        // định kỳ quét lại toàn bộ bản vẽ (phát hiện block bị phá/đổi)
        if (tick - lastFull >= 200) {
            lastFull = tick;
            for (Map.Entry<BlockPos, BlockState> e : bp.desired.entrySet()) {
                BlockPos pos = e.getKey();
                if (remaining.contains(pos)) continue;
                if (!w.getChunkManager().isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)) {
                    // chunk chưa tải: coi như chưa xong (không được báo "hoàn thành" nhầm), sẽ đi tới đó sau
                    if (!blocked.containsKey(pos)) remaining.add(pos);
                    continue;
                }
                BlockState have = w.getBlockState(pos);
                boolean ok = StateRules.baseMatches(have, e.getValue()) && !StateRules.needsConfigure(have, e.getValue());
                if (ok) {
                    if (blocked.remove(pos) != null) onCorrect(pos);
                } else if (!blocked.containsKey(pos)) {
                    remaining.add(pos);
                }
            }
        }

        Iterator<BlockPos> it = remaining.iterator();
        while (it.hasNext()) {
            BlockPos pos = it.next();
            BlockState want = bp.desired.get(pos);
            if (want == null) {
                it.remove();
                continue;
            }
            if (!w.getChunkManager().isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)) continue;
            BlockState have = w.getBlockState(pos);
            if (StateRules.baseMatches(have, want) && !StateRules.needsConfigure(have, want)) {
                onCorrect(pos);
                it.remove();
            }
        }
    }

    private void onCorrect(BlockPos pos) {
        if (attempts.remove(pos) != null) placed++;
        else alreadyCorrect++;
        retryAt.remove(pos);
        verifyUntil.remove(pos);
        whyNot.remove(pos);
        blocked.remove(pos);
    }

    // ================= Thất bại / kẹt =================

    private void delay(BlockPos pos, int ticks, String why) {
        retryAt.put(pos, tick + ticks);
        whyNot.put(pos, why);
    }

    private void fail(BlockPos pos, String why, Config cfg) {
        int a = attempts.merge(pos, 1, Integer::sum);
        if (a >= cfg.maxAttempts) block(pos, why);
        else delay(pos, 40L * a > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) (40L * a), why);
    }

    private void block(BlockPos pos, String why) {
        remaining.remove(pos);
        blocked.put(pos.toImmutable(), why);
    }

    // ================= Cài đặt Baritone =================

    private void applyBaritoneSettings() {
        Config cfg = Config.get();
        Settings s = BaritoneAPI.getSettings();
        savedAllowBreak = s.allowBreak.value;
        savedAllowPlace = s.allowPlace.value;
        s.allowBreak.value = cfg.allowBaritoneBreak;
        s.allowPlace.value = cfg.allowScaffold;
    }

    private void restoreBaritoneSettings() {
        Settings s = BaritoneAPI.getSettings();
        if (savedAllowBreak != null) s.allowBreak.value = savedAllowBreak;
        if (savedAllowPlace != null) s.allowPlace.value = savedAllowPlace;
        savedAllowBreak = null;
        savedAllowPlace = null;
    }

    // ================= Thông báo =================

    private void resetState() {
        remaining.clear();
        attempts.clear();
        retryAt.clear();
        verifyUntil.clear();
        whyNot.clear();
        blocked.clear();
        missing.clear();
        tick = 0;
        lastScan = -1000;
        lastFull = -1000;
        nextActionTick = 0;
        lastProgressTick = 0;
        lastRemainingSize = -1;
        placed = 0;
        alreadyCorrect = 0;
        currentTarget = null;
        lastGoal = null;
        arrivedTicks = 0;
        breaking = null;
    }

    private String missingText() {
        StringBuilder sb = new StringBuilder();
        int n = 0;
        for (Map.Entry<Item, Integer> e : missing.entrySet()) {
            if (n++ > 0) sb.append(", ");
            if (n > 10) {
                sb.append("...");
                break;
            }
            sb.append(e.getKey().getName().getString()).append(" x").append(e.getValue());
        }
        return sb.toString();
    }

    private void report() {
        say("Đã đặt " + placed + " block (" + alreadyCorrect + " ô vốn đã đúng), còn " + remaining.size() + " ô.");
        if (!blocked.isEmpty()) {
            say("§cKẹt " + blocked.size() + " ô§r (hiện tối đa 8):");
            int n = 0;
            for (Map.Entry<BlockPos, String> e : blocked.entrySet()) {
                if (n++ >= 8) break;
                BlockPos b = e.getKey();
                BlockState st = bp.desired.get(b);
                say(" - " + b.getX() + " " + b.getY() + " " + b.getZ() + " " + (st == null ? "?" : StateRules.id(st.getBlock())) + ": " + e.getValue());
            }
        }
        int shown = 0;
        for (BlockPos pos : remaining) {
            if (shown == 0) say("Các ô chưa làm được (tối đa 5):");
            if (shown++ >= 5) break;
            BlockState st = bp.desired.get(pos);
            say(" - " + pos.getX() + " " + pos.getY() + " " + pos.getZ() + " " + (st == null ? "?" : StateRules.id(st.getBlock()))
                + ": " + whyNot.getOrDefault(pos, "chưa tới lượt"));
        }
        if (bp.skippedFluid + bp.skippedNoItem + bp.skippedUnknown + bp.skippedDependent > 0) {
            say("Bỏ qua khi nạp: " + bp.skippedFluid + " ô nước/dung nham (đổ bằng xô), " + bp.skippedNoItem
                + " ô không có item (piston head, lửa...), " + bp.skippedUnknown + " block lạ, "
                + bp.skippedDependent + " nửa trên cửa/giường (tự có khi đặt nửa dưới).");
        }
    }

    private void say(String msg) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("§b[FarmBuild]§r " + msg), false);
    }

    private void bar(String msg) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(msg), true);
    }
}
