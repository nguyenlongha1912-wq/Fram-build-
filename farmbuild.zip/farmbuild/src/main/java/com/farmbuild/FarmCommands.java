package com.farmbuild;

import com.farmbuild.process.FarmProcess;
import com.farmbuild.schem.Blueprint;
import com.farmbuild.schem.SchematicLoader;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.lang.reflect.Field;
import java.nio.file.Path;
import java.util.List;

/**
 * /farmbuild list
 * /farmbuild load <tên file>                 — đặt góc nhỏ nhất của bản vẽ tại chỗ bạn đang đứng
 * /farmbuild loadat <x> <y> <z> <tên file>   — đặt tại toạ độ chỉ định
 * /farmbuild start | stop | status
 * /farmbuild set <khoá> <giá trị>
 */
final class FarmCommands {
    private FarmCommands() {}

    private static final SuggestionProvider<FabricClientCommandSource> FILES = (ctx, b) -> {
        for (String n : SchematicLoader.listFiles()) b.suggest(n);
        return b.buildFuture();
    };

    private static final SuggestionProvider<FabricClientCommandSource> KEYS = (ctx, b) -> {
        for (Field f : Config.class.getFields()) {
            if (!java.lang.reflect.Modifier.isStatic(f.getModifiers())) b.suggest(f.getName());
        }
        return b.buildFuture();
    };

    static void register(CommandDispatcher<FabricClientCommandSource> d) {
        d.register(ClientCommandManager.literal("farmbuild")
            .then(ClientCommandManager.literal("list").executes(c -> list(c.getSource())))
            .then(ClientCommandManager.literal("load")
                .then(ClientCommandManager.argument("file", StringArgumentType.greedyString()).suggests(FILES)
                    .executes(c -> load(c.getSource(), StringArgumentType.getString(c, "file"), null))))
            .then(ClientCommandManager.literal("loadat")
                .then(ClientCommandManager.argument("x", IntegerArgumentType.integer())
                    .then(ClientCommandManager.argument("y", IntegerArgumentType.integer())
                        .then(ClientCommandManager.argument("z", IntegerArgumentType.integer())
                            .then(ClientCommandManager.argument("file", StringArgumentType.greedyString()).suggests(FILES)
                                .executes(c -> load(c.getSource(), StringArgumentType.getString(c, "file"),
                                    new BlockPos(IntegerArgumentType.getInteger(c, "x"),
                                        IntegerArgumentType.getInteger(c, "y"),
                                        IntegerArgumentType.getInteger(c, "z")))))))))
            .then(ClientCommandManager.literal("litematica").executes(c -> fromLitematica(c.getSource())))
            .then(ClientCommandManager.literal("start").executes(c -> start(c.getSource())))
            .then(ClientCommandManager.literal("clean").executes(c -> clean(c.getSource())))
            .then(ClientCommandManager.literal("stop").executes(c -> stop(c.getSource())))
            .then(ClientCommandManager.literal("status").executes(c -> status(c.getSource())))
            .then(ClientCommandManager.literal("set")
                .then(ClientCommandManager.argument("key", StringArgumentType.word()).suggests(KEYS)
                    .then(ClientCommandManager.argument("value", StringArgumentType.word())
                        .executes(c -> set(c.getSource(), StringArgumentType.getString(c, "key"),
                            StringArgumentType.getString(c, "value"))))))
        );
    }

    private static int list(FabricClientCommandSource src) {
        List<String> files = SchematicLoader.listFiles();
        if (files.isEmpty()) {
            src.sendFeedback(Text.literal("Không có file nào trong " + SchematicLoader.dir()
                + " (hỗ trợ .litematic .nbt .schem .schematic)."));
            return 0;
        }
        src.sendFeedback(Text.literal("Bản vẽ trong " + SchematicLoader.dir() + ":"));
        for (String f : files) src.sendFeedback(Text.literal(" - " + f));
        return files.size();
    }

    private static int load(FabricClientCommandSource src, String name, BlockPos origin) {
        FarmProcess proc = FarmBuildClient.process();
        if (proc == null) return err(src, "Baritone chưa sẵn sàng (vào thế giới rồi thử lại).");
        Path file = SchematicLoader.resolve(name.trim());
        if (file == null) return err(src, "Không thấy '" + name + "' trong " + SchematicLoader.dir() + ". Gõ /farmbuild list.");
        BlockPos o = origin != null ? origin : src.getPlayer().getBlockPos();
        try {
            Blueprint bp = SchematicLoader.load(file, o);
            proc.setBlueprint(bp);
            src.sendFeedback(Text.literal("§b[FarmBuild]§r Đã nạp §e" + bp.name + "§r: " + bp.size() + " block cần đặt, tầng Y "
                + bp.minY + " → " + bp.maxY + ", góc nhỏ nhất tại " + o.getX() + " " + o.getY() + " " + o.getZ()
                + ". Gõ /farmbuild start để xây."));
            if (bp.skippedFluid > 0 || bp.skippedNoItem > 0 || bp.skippedUnknown > 0) {
                src.sendFeedback(Text.literal("Bỏ qua: " + bp.skippedFluid + " nước/dung nham, " + bp.skippedNoItem
                    + " ô không có item, " + bp.skippedUnknown + " block lạ."));
            }
            return 1;
        } catch (Exception e) {
            return err(src, "Không đọc được file: " + e);
        }
    }

    private static int fromLitematica(FabricClientCommandSource src) {
        FarmProcess proc = FarmBuildClient.process();
        if (proc == null) return err(src, "Baritone chưa sẵn sàng (vào thế giới rồi thử lại).");
        try {
            LitematicaBridge.Placement pl = LitematicaBridge.current();
            Blueprint bp = SchematicLoader.loadPlaced(pl.file(), pl.origin(), pl.rotation(), pl.mirror());
            proc.setBlueprint(bp);
            BlockPos o = pl.origin();
            src.sendFeedback(Text.literal("§b[FarmBuild]§r Lấy từ Litematica: §e" + bp.name + "§r, " + bp.size()
                + " block cần đặt, origin " + o.getX() + " " + o.getY() + " " + o.getZ()
                + ", xoay " + pl.rotation() + ", lật " + pl.mirror() + ". Gõ /farmbuild start để xây."));
            return 1;
        } catch (Exception e) {
            return err(src, e.getMessage() != null ? e.getMessage() : e.toString());
        }
    }

    private static int start(FabricClientCommandSource src) {
        FarmProcess proc = FarmBuildClient.process();
        if (proc == null) return err(src, "Baritone chưa sẵn sàng.");
        String e = proc.start();
        return e == null ? 1 : err(src, e);
    }

    private static int clean(FabricClientCommandSource src) {
        FarmProcess proc = FarmBuildClient.process();
        if (proc == null) return err(src, "Baritone chưa sẵn sàng.");
        String e = proc.cleanup();
        if (e != null) return err(src, e);
        return 1;
    }

    private static int stop(FabricClientCommandSource src) {
        FarmProcess proc = FarmBuildClient.process();
        if (proc == null) return err(src, "Baritone chưa sẵn sàng.");
        if (!proc.isRunning()) {
            src.sendFeedback(Text.literal("Đang không chạy."));
            return 0;
        }
        proc.stop("Đã dừng.");
        return 1;
    }

    private static int status(FabricClientCommandSource src) {
        FarmProcess proc = FarmBuildClient.process();
        src.sendFeedback(Text.literal(proc == null ? "Baritone chưa sẵn sàng." : proc.status()));
        return 1;
    }

    private static int set(FabricClientCommandSource src, String key, String value) {
        String e = Config.set(key, value);
        if (e != null) return err(src, e);
        src.sendFeedback(Text.literal(key + " = " + value));
        return 1;
    }

    private static int err(FabricClientCommandSource src, String msg) {
        src.sendError(Text.literal(msg));
        return 0;
    }
}
