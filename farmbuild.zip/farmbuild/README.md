# FarmBuild — mod Fabric 1.21.11 xây farm từ bản vẽ

Đi bằng **Baritone** (tìm đường, tránh lạc/kẹt), đặt block kiểu **Easy Redstone**
(tự chọn mặt/hướng đúng, tự ngồi (sneak), giả lập góc nhìn khi cần).

## 1. Build

Project đã đủ file để build luôn (Gradle, Baritone trong `libs/`). **Chưa biên dịch thật với Minecraft** nên có thể còn lỗi — gửi lại log để sửa.

**Cách A — GitHub Actions (không cần máy tính):**
1. Tạo repo trống trên GitHub, đẩy toàn bộ nội dung thư mục `farmbuild/` lên (giữ nguyên `.github/workflows/build.yml`).
2. Tab **Actions** → chạy workflow `build` (tự chạy mỗi lần push).
3. Xong, mở lần chạy đó → mục **Artifacts** → tải `farmbuild-mods` (có sẵn `farmbuild-1.0.0.jar` + jar Baritone).

**Cách B — trên máy tính:** cài Java 21 + Gradle 9.2, chạy `gradle build` trong thư mục này; jar ở `build/libs/`.

## 2. Cài vào game

Thư mục `mods/` cần có cả 3: `farmbuild-1.0.0.jar`, `baritone-api-fabric-1.17.0.jar` (bản này là Baritone đầy đủ, không chỉ API), và Fabric API.

## 3. Dùng

Bỏ bản vẽ vào `.minecraft/schematics/` (hỗ trợ `.litematic`, `.nbt`, `.schem`, `.schematic`).

| Lệnh | Việc |
|---|---|
| `/farmbuild list` | liệt kê bản vẽ |
| `/farmbuild load <file>` | nạp, góc nhỏ nhất đặt tại block bạn đang đứng |
| `/farmbuild loadat <x> <y> <z> <file>` | nạp tại toạ độ chỉ định |
| `/farmbuild litematica` | lấy đúng bản vẽ đang đặt (selected placement) trong Litematica: cùng vị trí, xoay, lật |
| `/farmbuild start` / `stop` / `status` | chạy / dừng / xem tiến độ |
| `/farmbuild set <khoá> <giá trị>` | đổi cấu hình |

Phím **K** bật/tắt nhanh. Cấu hình lưu ở `config/farmbuild.json`.

Khoá cấu hình chính: `reach` (4.0), `placeDelay` (2 tick), `nearRadius` (10), `requireLineOfSight` (true), `spoofRotation` (true), `alwaysSneak` (false), `breakWrong` (false — bật thì tự phá block sai), `goalRange` (3), `maxAttempts` (5), `stallSeconds` (45).

## 3b. Xây từng tầng

- Xây **từng tầng một** từ dưới lên; tầng nào xong (đặt đủ, đúng trạng thái, dọn sạch) mới lên tầng kế. Hết bản vẽ thì tự dừng.
- Block **sai** ở ô cần đặt và block **thừa** (không có trong bản vẽ, nằm trong vùng bản vẽ) đều bị phá (`breakWrong`, `clearExtra`, mặc định bật).
- Cửa, trapdoor, cổng, cần gạt, repeater, comparator, note block: tự bấm cho đúng trạng thái (mở/đóng, bật/tắt, delay, mode, nốt) sau khi xong phần đặt của tầng. Cửa/trapdoor sắt không bấm tay được nên bị bỏ qua.

## 4. Cách hoạt động

- Mỗi vài tick so bản vẽ với thế giới → danh sách block còn thiếu/sai.
- Ưu tiên: đặt ngay mọi thứ trong tầm với; nếu không có thì đi tới block tiếp theo tốt nhất.
- Thứ tự: từ dưới lên, block nền → máy/block có hướng → block bám (đuốc, nút, dust...).
- Với mỗi block, thử mọi mặt tựa × điểm chạm × góc quay, mô phỏng `getPlacementState` và chỉ chọn cách ra **đúng trạng thái** cần.
- Repeater (delay) và comparator (mode) được chỉnh bằng chuột phải sau khi đặt.
- Block thất bại bị lùi thời gian thử lại; kẹt quá lâu thì báo lý do và dừng.

## 5. Giới hạn đã biết

- Nước/dung nham trong bản vẽ bị bỏ qua (tự đổ bằng xô).
- Không xoay bản vẽ.
- Thiếu block tựa thì không tự dựng giàn — báo là bị kẹt.
- Thiếu vật liệu thì dừng và báo loại còn thiếu.
- **Server công khai có anti-cheat có thể ban** (giả lập góc nhìn + tự xây). Dùng ở singleplayer hoặc server của bạn.
